# Salon Booking, Inventory & Payments Platform

**Team Dunamis** · COE 454 — Software Engineering II, KNUST

A production-quality web platform for a salon business: online appointment booking with
category-based daily capacity limits, product inventory with automatic stock deduction,
Mobile Money payments, and a single admin dashboard for the salon owner. Fully responsive
for mobile and desktop.

## Tech stack

| Layer      | Choice                              | ADR     |
| ---------- | ----------------------------------- | ------- |
| Frontend   | Next.js 16 (React 19, Tailwind 4)   | ADR-001 |
| Backend    | Node.js 22 + Express 5 (TypeScript) | ADR-002 |
| Database   | PostgreSQL 16 (Prisma ORM)          | ADR-003 |
| Auth       | JWT + bcrypt, role-based access     | ADR-004 |
| Deployment | Vercel (frontend) · Railway (API+DB)| ADR-005 |
| Payments   | Provider abstraction: Paystack MoMo / mock | — |

Full architecture decisions, ERD and API schema: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Quick start (local)

Prerequisites: Node.js 18+ (22 recommended), npm, Docker (for Postgres).

```bash
# 1. Start the databases (dev on :5433, test on :5434)
docker compose up -d db db_test

# 2. Backend
cd backend
cp .env.example .env          # defaults work for local dev
npm install
npm run migrate               # apply migrations
npm run seed                  # demo catalog + admin account
npm run dev                   # → http://localhost:4000/api

# 3. Frontend (new terminal)
cd frontend
cp .env.example .env.local
npm install
npm run dev                   # → http://localhost:3000
```

**Demo admin login:** phone `233240000000`, password `ChangeMe!123` (change via `ADMIN_*`
env vars before seeding in any real environment).

Payments run against the built-in **mock provider** by default (`PAYMENT_PROVIDER=mock`)
so the full book→pay→confirm flow works offline. Set `PAYMENT_PROVIDER=paystack` and
`PAYSTACK_SECRET_KEY` for real Mobile Money charges.

## Scripts

| Where    | Command             | What it does                              |
| -------- | ------------------- | ----------------------------------------- |
| backend  | `npm run dev`       | API with hot reload                       |
| backend  | `npm test`          | 24 API/integration tests (needs `db_test`)|
| backend  | `npm run lint` / `typecheck` | ESLint / strict TypeScript       |
| backend  | `npm run migrate:dev`| Create + apply a new migration           |
| frontend | `npm run dev`       | Next.js dev server                        |
| frontend | `npm run build`     | Production build                          |

## Repository structure

```
salon-platform/
├── backend/          # Express API (TypeScript), Prisma schema + migrations, tests
│   └── src/modules/  # auth · categories · services · bookings · products · orders · payments · admin
├── frontend/         # Next.js app — customer site + /admin dashboard
├── docs/             # Architecture, API reference, database, deployment, project plan
├── docker-compose.yml
└── .github/workflows/ci.yml
```

## Testing & CI

- `backend/tests/` — 24 tests via Vitest + Supertest against a throwaway Postgres,
  covering auth, RBAC, the booking daily-cap rule (including a concurrency race),
  stock deduction on payment, and audit logging.
- GitHub Actions runs lint + typecheck + tests (backend) and lint + typecheck + build
  (frontend) on every PR and push to `main`.

## Branching & PR rules

- No direct pushes to `main`; all code goes through a pull request.
- Every PR needs at least one peer review before merge, per the Team Charter.
- Branch naming: `feature/<short-description>`, `fix/<short-description>`.

## Documentation

| Doc | Contents |
| --- | -------- |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | ADRs, system design, key mechanisms, documented assumptions |
| [`docs/API.md`](docs/API.md)                   | Full REST endpoint reference |
| [`docs/DATABASE.md`](docs/DATABASE.md)         | Schema, relationships, integrity rules |
| [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md)     | Vercel + Railway deploys, env vars, rollback |
| [`docs/PROJECT_PLAN.md`](docs/PROJECT_PLAN.md) | Requirements analysis, progress checklist, known issues |

## Team

| Role | Name |
| ---- | ---- |
| Project Manager | Prince Djangmah |
| Business Analyst / Client Liaison / Frontend | Naomi Opuni |
| UX / Design Lead | Esther Tweneboah Koduah |
| Backend Engineer (Lead) | Nkansah Noel Gerhard Yaw |
| Backend Engineer | Klogo Enyo Kweku |
| Frontend Engineer | Allen Sampah |
| QA / Documentation Lead | Asiedu Enoch Ofori |
