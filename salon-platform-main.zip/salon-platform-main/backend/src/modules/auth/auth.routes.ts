/**
 * Auth endpoints: register (US-01), login (US-02), and current-user lookup.
 * Passwords are bcrypt-hashed before storage (NFR-03); both endpoints sit
 * behind the strict auth rate limiter.
 */
import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { audit } from "../../lib/audit";
import { ApiError } from "../../lib/errors";
import { signToken, requireAuth } from "../../middleware/auth";
import { validateBody } from "../../middleware/validate";
import { authLimiter } from "../../middleware/rateLimit";

const phoneSchema = z
  .string()
  .trim()
  .regex(/^\+?\d{9,15}$/, "Enter a valid phone number (digits only, e.g. 0241234567)");

const registerSchema = z.object({
  name: z.string().trim().min(2, "Name is too short").max(100),
  phone: phoneSchema,
  email: z.email("Enter a valid email").optional(),
  password: z.string().min(8, "Password must be at least 8 characters").max(200),
});

const loginSchema = z.object({
  // Accepts phone number or email in a single identifier field
  identifier: z.string().trim().min(3),
  password: z.string().min(1),
});

/** Strip sensitive fields (passwordHash, deletedAt) before sending a user to clients. */
function publicUser(user: {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  role: string;
  createdAt: Date;
}) {
  return {
    id: user.id,
    name: user.name,
    phone: user.phone,
    email: user.email,
    role: user.role,
    createdAt: user.createdAt,
  };
}

export const authRouter = Router();

// US-01: signup with duplicate-phone prevention
authRouter.post("/register", authLimiter, validateBody(registerSchema), async (req, res) => {
  const { name, phone, email, password } = req.body as z.infer<typeof registerSchema>;

  const existing = await prisma.user.findFirst({
    where: { OR: [{ phone }, ...(email ? [{ email }] : [])] },
  });
  if (existing) {
    throw ApiError.conflict("An account with this phone number or email already exists");
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: { name, phone, email: email ?? null, passwordHash },
  });

  res.status(201).json({ user: publicUser(user), token: signToken(user) });
});

// US-02: login without revealing which credential was wrong
authRouter.post("/login", authLimiter, validateBody(loginSchema), async (req, res) => {
  const { identifier, password } = req.body as z.infer<typeof loginSchema>;

  const user = await prisma.user.findFirst({
    where: { OR: [{ phone: identifier }, { email: identifier }], deletedAt: null },
  });
  const valid = user && (await bcrypt.compare(password, user.passwordHash));
  if (!valid) {
    throw ApiError.unauthorized("Incorrect phone/email or password", "INVALID_CREDENTIALS");
  }

  res.json({ user: publicUser(user), token: signToken(user) });
});

// Used by the frontend on page load to restore a stored session
authRouter.get("/me", requireAuth, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  if (!user || user.deletedAt) throw ApiError.unauthorized();
  res.json({ user: publicUser(user) });
});

const updateProfileSchema = z
  .object({
    name: z.string().trim().min(2, "Name is too short").max(100),
    phone: phoneSchema,
    email: z.email("Enter a valid email").nullable(),
  })
  .partial();

// Update own profile (name / phone / email). Phone and email must stay
// unique because both work as login identifiers.
authRouter.put(
  "/me",
  requireAuth,
  validateBody(updateProfileSchema),
  async (req, res) => {
    const data = req.body as z.infer<typeof updateProfileSchema>;

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user || user.deletedAt) throw ApiError.unauthorized();

    const identifierChecks = [
      ...(data.phone && data.phone !== user.phone ? [{ phone: data.phone }] : []),
      ...(data.email && data.email !== user.email ? [{ email: data.email }] : []),
    ];
    if (identifierChecks.length > 0) {
      const taken = await prisma.user.findFirst({
        where: { OR: identifierChecks, NOT: { id: user.id } },
      });
      if (taken) {
        throw ApiError.conflict("An account with this phone number or email already exists");
      }
    }

    const updated = await prisma.user.update({ where: { id: user.id }, data });
    res.json({ user: publicUser(updated) });
  },
);

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8, "Password must be at least 8 characters").max(200),
});

// Any signed-in user (customer or admin) can change their own password.
// Requires the current password so a stolen token alone isn't enough.
authRouter.put(
  "/password",
  authLimiter,
  requireAuth,
  validateBody(changePasswordSchema),
  async (req, res) => {
    const { currentPassword, newPassword } = req.body as z.infer<typeof changePasswordSchema>;

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user || user.deletedAt) throw ApiError.unauthorized();

    const valid = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!valid) {
      throw ApiError.unauthorized("Current password is incorrect", "INVALID_CREDENTIALS");
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    await prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: user.id }, data: { passwordHash } });
      await audit(tx, {
        actorId: user.id,
        action: "PASSWORD_CHANGED",
        entityType: "User",
        entityId: user.id,
      });
    });

    res.status(204).end();
  },
);
