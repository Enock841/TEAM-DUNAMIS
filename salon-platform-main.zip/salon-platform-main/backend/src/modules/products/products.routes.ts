/**
 * Product catalog + inventory endpoints (US-07 browsing, US-08 stock).
 * Note: regular product updates (PUT /:id) intentionally cannot change
 * stockQty — stock only moves through the audited /:id/stock endpoint or
 * automatic deduction on successful payment, keeping NFR-07 airtight.
 */
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { audit } from "../../lib/audit";
import { requireAdmin } from "../../middleware/auth";
import { validateBody } from "../../middleware/validate";

const productSchema = z.object({
  name: z.string().trim().min(2).max(100),
  description: z.string().trim().max(2000).default(""),
  price: z.number().int().min(0),
  stockQty: z.number().int().min(0).default(0),
  imageUrl: z.url().nullish(),
  active: z.boolean().default(true),
});

const stockSchema = z.object({
  stockQty: z.number().int().min(0),
  reason: z.string().trim().max(200).optional(),
});

/** Adds the derived `inStock` flag the storefront renders (US-08 AC2). */
function withStockStatus<T extends { stockQty: number }>(p: T) {
  return { ...p, inStock: p.stockQty > 0 };
}

export const productsRouter = Router();

// US-07: public product list with stock status (out-of-stock still shown, marked)
productsRouter.get("/", async (_req, res) => {
  const products = await prisma.product.findMany({
    where: { active: true, deletedAt: null },
    orderBy: { name: "asc" },
  });
  res.json(products.map(withStockStatus));
});

productsRouter.get("/all", requireAdmin, async (_req, res) => {
  const products = await prisma.product.findMany({
    where: { deletedAt: null },
    orderBy: { name: "asc" },
  });
  res.json(products.map(withStockStatus));
});

productsRouter.get("/:id", async (req, res) => {
  const product = await prisma.product.findFirst({
    where: { id: param(req, "id"), active: true, deletedAt: null },
  });
  if (!product) throw ApiError.notFound("Product not found");
  res.json(withStockStatus(product));
});

productsRouter.post("/", requireAdmin, validateBody(productSchema), async (req, res) => {
  const data = req.body as z.infer<typeof productSchema>;
  const product = await prisma.product.create({
    data: { ...data, imageUrl: data.imageUrl ?? null },
  });
  res.status(201).json({ product: withStockStatus(product) });
});

productsRouter.put(
  "/:id",
  requireAdmin,
  validateBody(productSchema.partial()),
  async (req, res) => {
    const existing = await prisma.product.findFirst({
      where: { id: param(req, "id"), deletedAt: null },
    });
    if (!existing) throw ApiError.notFound("Product not found");
    const product = await prisma.product.update({ where: { id: existing.id }, data: req.body });
    res.json({ product: withStockStatus(product) });
  },
);

// US-08 AC3: manual stock adjustment, audited per NFR-07
productsRouter.put("/:id/stock", requireAdmin, validateBody(stockSchema), async (req, res) => {
  const { stockQty, reason } = req.body as z.infer<typeof stockSchema>;
  const existing = await prisma.product.findFirst({
    where: { id: param(req, "id"), deletedAt: null },
  });
  if (!existing) throw ApiError.notFound("Product not found");

  const product = await prisma.$transaction(async (tx) => {
    const updated = await tx.product.update({
      where: { id: existing.id },
      data: { stockQty },
    });
    await audit(tx, {
      actorId: req.user!.id,
      action: "STOCK_ADJUSTED",
      entityType: "Product",
      entityId: existing.id,
      detail: { from: existing.stockQty, to: stockQty, reason: reason ?? "manual adjustment" },
    });
    return updated;
  });

  res.json({ product: withStockStatus(product) });
});

productsRouter.delete("/:id", requireAdmin, async (req, res) => {
  const existing = await prisma.product.findFirst({
    where: { id: param(req, "id"), deletedAt: null },
  });
  if (!existing) throw ApiError.notFound("Product not found");
  await prisma.product.update({
    where: { id: existing.id },
    data: { deletedAt: new Date(), active: false },
  });
  res.status(204).end();
});
