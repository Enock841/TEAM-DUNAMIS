/**
 * Payment endpoints (US-09/US-10): initiate a Mobile Money charge, receive
 * the provider webhook, check a payment's status, and the admin payment
 * log. Settlement/business rules live in payments.service.ts.
 */
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { logger } from "../../lib/logger";
import { env } from "../../config/env";
import { requireAuth, requireAdmin } from "../../middleware/auth";
import { validateBody } from "../../middleware/validate";
import { initiatePayment, settlePayment, paymentProvider } from "./payments.service";

const initiateSchema = z.object({
  type: z.enum(["booking", "order"]),
  refId: z.uuid(),
  momoNumber: z
    .string()
    .trim()
    .regex(/^\+?\d{9,15}$/, "Enter a valid Mobile Money number"),
});

export const paymentsRouter = Router();

// US-09: start a MoMo charge for a booking or order
paymentsRouter.post("/initiate", requireAuth, validateBody(initiateSchema), async (req, res) => {
  const body = req.body as z.infer<typeof initiateSchema>;
  const result = await initiatePayment({
    userId: req.user!.id,
    userName: req.user!.name,
    ...body,
  });
  res.status(201).json(result);
});

// Provider webhook (Paystack signs with HMAC-SHA512 in x-paystack-signature).
// Mounted with raw body capture in app.ts.
paymentsRouter.post("/webhook", async (req, res) => {
  const rawBody = (req as unknown as { rawBody?: Buffer }).rawBody ?? Buffer.from("");
  const signature = req.headers["x-paystack-signature"] as string | undefined;

  if (!paymentProvider.verifyWebhookSignature(rawBody, signature)) {
    logger.warn("Rejected webhook with bad signature");
    res.status(401).json({ received: false });
    return;
  }

  const event = req.body as {
    event?: string;
    data?: { reference?: string; status?: string };
  };
  const reference = event.data?.reference;

  if (reference) {
    if (event.event === "charge.success") {
      await settlePayment(reference, "SUCCESS", reference);
    } else if (event.event === "charge.failed") {
      await settlePayment(reference, "FAILED", reference);
    }
  }

  res.json({ received: true });
});

// Dev-only helper: settle a pending mock payment (simulates the webhook)
if (env.paymentProvider === "mock" && !env.isProd) {
  paymentsRouter.post(
    "/mock/settle",
    validateBody(z.object({ reference: z.string(), outcome: z.enum(["SUCCESS", "FAILED"]) })),
    async (req, res) => {
      const { reference, outcome } = req.body as { reference: string; outcome: "SUCCESS" | "FAILED" };
      await settlePayment(reference, outcome);
      res.json({ ok: true });
    },
  );
}

// US-10 AC2/AC3: admin payment log with clear status distinction
paymentsRouter.get("/", requireAdmin, async (_req, res) => {
  const payments = await prisma.payment.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      booking: { select: { id: true, date: true, service: { select: { name: true } } } },
      order: { select: { id: true, totalMinor: true } },
    },
  });
  res.json(payments);
});

// US-09 AC3: customer checks their payment status by reference
paymentsRouter.get("/:reference", requireAuth, async (req, res) => {
  const payment = await prisma.payment.findUnique({
    where: { reference: param(req, "reference") },
    include: {
      booking: { select: { id: true, userId: true, status: true } },
      order: { select: { id: true, userId: true, status: true } },
    },
  });
  if (!payment) throw ApiError.notFound("Payment not found");

  const ownerId = payment.booking?.userId ?? payment.order?.userId;
  if (ownerId !== req.user!.id && req.user!.role !== "ADMIN") {
    throw ApiError.forbidden();
  }

  res.json({
    reference: payment.reference,
    status: payment.status,
    amountMinor: payment.amountMinor,
    currency: payment.currency,
    type: payment.type,
    refId: payment.bookingId ?? payment.orderId,
    refStatus: payment.booking?.status ?? payment.order?.status,
  });
});
