import crypto from "node:crypto";
import { env } from "../../config/env";
import { logger } from "../../lib/logger";
import type { ChargeOutcome, ChargeRequest, PaymentProvider } from "./provider";

const PAYSTACK_BASE = "https://api.paystack.co";

/**
 * Paystack Mobile Money charge (Ghana: MTN MoMo, Vodafone Cash, AirtelTigo).
 * Docs: https://paystack.com/docs/payments/payment-channels/#mobile-money
 *
 * Settlement to the owner's MoMo wallet (US-10) is configured on the
 * Paystack dashboard as the business's settlement account.
 */
export class PaystackProvider implements PaymentProvider {
  readonly name = "paystack";

  async charge(request: ChargeRequest): Promise<ChargeOutcome> {
    const response = await fetch(`${PAYSTACK_BASE}/charge`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.paystackSecretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        // Paystack requires an email; synthesize a routable-looking one from
        // the phone when the customer has no email on file.
        email: `${request.momoNumber}@customers.salon.local`,
        amount: request.amountMinor,
        currency: request.currency,
        reference: request.reference,
        mobile_money: { phone: request.momoNumber, provider: "mtn" },
      }),
    });

    const body = (await response.json()) as {
      status: boolean;
      message?: string;
      data?: { status?: string; reference?: string };
    };

    if (!response.ok || !body.status) {
      logger.warn({ body }, "Paystack charge rejected");
      return { status: "FAILED", reason: body.message ?? "Charge rejected" };
    }

    const chargeStatus = body.data?.status;
    if (chargeStatus === "success") {
      return { status: "SUCCESS", providerRef: body.data?.reference };
    }
    // "pay_offline" / "send_otp" / "pending": customer must approve on phone;
    // final state arrives via webhook.
    return { status: "PENDING", providerRef: body.data?.reference };
  }

  verifyWebhookSignature(rawBody: Buffer, signature: string | undefined): boolean {
    if (!signature || !env.paystackSecretKey) return false;
    const expected = crypto
      .createHmac("sha512", env.paystackSecretKey)
      .update(rawBody)
      .digest("hex");
    return (
      signature.length === expected.length &&
      crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))
    );
  }
}
