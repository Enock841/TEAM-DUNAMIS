/**
 * Payment provider abstraction (US-09/US-10).
 *
 * The platform never stores card/wallet credentials (NFR-03) — it only
 * initiates a charge with a PCI-compliant gateway and records the result.
 * Settlement to the owner's MoMo number is configured at the gateway
 * (e.g. the Paystack settlement account), not in application code.
 */
export interface ChargeRequest {
  reference: string;
  amountMinor: number;
  currency: string;
  momoNumber: string;
  customerName: string;
}

export type ChargeOutcome =
  | { status: "SUCCESS"; providerRef?: string }
  | { status: "PENDING"; providerRef?: string }
  | { status: "FAILED"; providerRef?: string; reason?: string };

export interface PaymentProvider {
  readonly name: string;
  charge(request: ChargeRequest): Promise<ChargeOutcome>;
  /** Verify a webhook signature. Returns false to reject the event. */
  verifyWebhookSignature(rawBody: Buffer, signature: string | undefined): boolean;
}
