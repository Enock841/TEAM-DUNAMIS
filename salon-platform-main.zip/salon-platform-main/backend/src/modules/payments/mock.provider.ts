import type { ChargeOutcome, ChargeRequest, PaymentProvider } from "./provider";

/**
 * Development/demo provider: no real money moves. The outcome is
 * controlled with MOCK_PAYMENT_OUTCOME (success | pending | failed),
 * defaulting to success so the end-to-end flow is demoable offline.
 */
export class MockPaymentProvider implements PaymentProvider {
  readonly name = "mock";

  async charge(_request: ChargeRequest): Promise<ChargeOutcome> {
    const outcome = (process.env.MOCK_PAYMENT_OUTCOME ?? "success").toLowerCase();
    if (outcome === "failed") return { status: "FAILED", reason: "Mock decline" };
    if (outcome === "pending") return { status: "PENDING", providerRef: "mock-pending" };
    return { status: "SUCCESS", providerRef: "mock-success" };
  }

  verifyWebhookSignature(): boolean {
    // Mock webhooks are only enabled outside production (see routes).
    return true;
  }
}
