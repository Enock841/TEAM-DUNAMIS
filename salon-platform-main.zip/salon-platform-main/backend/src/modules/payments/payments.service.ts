/**
 * Payment domain logic (US-09/US-10). Flow:
 *
 *   initiatePayment ── charge via provider ──► SUCCESS ─┐
 *        │                                  ► FAILED  ──┤─► settlePayment
 *        └─► PENDING … provider webhook later ──────────┘
 *
 * settlePayment is the single place where money outcomes touch business
 * state: confirming bookings, marking orders paid, and deducting stock.
 */
import crypto from "node:crypto";
import { prisma } from "../../lib/prisma";
import { ApiError } from "../../lib/errors";
import { audit } from "../../lib/audit";
import { logger } from "../../lib/logger";
import { env } from "../../config/env";
import type { PaymentProvider } from "./provider";
import { MockPaymentProvider } from "./mock.provider";
import { PaystackProvider } from "./paystack.provider";

// Selected once at boot from PAYMENT_PROVIDER (mock for dev/demo, paystack for real charges)
export const paymentProvider: PaymentProvider =
  env.paymentProvider === "paystack" ? new PaystackProvider() : new MockPaymentProvider();

/** Unguessable customer-facing payment reference, e.g. PAY-1A2B3C4D5E6F7A8B. */
function newReference(): string {
  return `PAY-${crypto.randomBytes(8).toString("hex").toUpperCase()}`;
}

/**
 * US-09: initiate payment for a booking or an order the caller owns.
 * Amount always comes from the server-side entity, never the client.
 */
export async function initiatePayment(input: {
  userId: string;
  userName: string;
  type: "booking" | "order";
  refId: string;
  momoNumber: string;
}) {
  let amountMinor: number;
  let bookingId: string | null = null;
  let orderId: string | null = null;

  if (input.type === "booking") {
    const booking = await prisma.booking.findFirst({
      where: { id: input.refId, userId: input.userId },
      include: { service: true },
    });
    if (!booking) throw ApiError.notFound("Booking not found");
    if (booking.status !== "PENDING_PAYMENT") {
      throw ApiError.conflict("This booking is not awaiting payment");
    }
    amountMinor = booking.service.priceMin;
    bookingId = booking.id;
  } else {
    const order = await prisma.order.findFirst({
      where: { id: input.refId, userId: input.userId },
    });
    if (!order) throw ApiError.notFound("Order not found");
    if (order.status !== "PENDING_PAYMENT") {
      throw ApiError.conflict("This order is not awaiting payment");
    }
    amountMinor = order.totalMinor;
    orderId = order.id;
  }

  const payment = await prisma.payment.create({
    data: {
      reference: newReference(),
      type: input.type === "booking" ? "BOOKING" : "ORDER",
      bookingId,
      orderId,
      amountMinor,
      momoNumber: input.momoNumber,
      provider: paymentProvider.name,
    },
  });

  const outcome = await paymentProvider.charge({
    reference: payment.reference,
    amountMinor,
    currency: payment.currency,
    momoNumber: input.momoNumber,
    customerName: input.userName,
  });

  if (outcome.status === "SUCCESS") {
    await settlePayment(payment.reference, "SUCCESS", outcome.providerRef);
  } else if (outcome.status === "FAILED") {
    await settlePayment(payment.reference, "FAILED", outcome.providerRef, outcome.reason);
  } else if (outcome.providerRef) {
    await prisma.payment.update({
      where: { id: payment.id },
      data: { providerRef: outcome.providerRef },
    });
  }

  const fresh = await prisma.payment.findUniqueOrThrow({ where: { id: payment.id } });
  return { reference: fresh.reference, status: fresh.status, amountMinor: fresh.amountMinor };
}

/**
 * Terminal payment handling — called from the charge response or the
 * provider webhook. Idempotent: an already-settled payment is left alone.
 *
 * On success:
 *  - a booking payment confirms the booking (US-09 AC2)
 *  - an order payment marks the order paid and decrements stock
 *    transactionally with an oversell guard (US-08)
 */
export async function settlePayment(
  reference: string,
  status: "SUCCESS" | "FAILED",
  providerRef?: string,
  reason?: string,
): Promise<void> {
  await prisma.$transaction(async (tx) => {
    const payment = await tx.payment.findUnique({
      where: { reference },
      include: { order: { include: { items: true } }, booking: true },
    });
    if (!payment) throw ApiError.notFound("Payment not found");
    if (payment.status !== "PENDING") return; // idempotent

    await tx.payment.update({
      where: { id: payment.id },
      data: { status, providerRef: providerRef ?? payment.providerRef },
    });
    await audit(tx, {
      action: status === "SUCCESS" ? "PAYMENT_SUCCEEDED" : "PAYMENT_FAILED",
      entityType: "Payment",
      entityId: payment.id,
      detail: { reference, amountMinor: payment.amountMinor, reason },
    });

    if (status !== "SUCCESS") return;

    if (payment.booking && payment.booking.status === "PENDING_PAYMENT") {
      await tx.booking.update({
        where: { id: payment.booking.id },
        data: { status: "CONFIRMED" },
      });
      await audit(tx, {
        action: "BOOKING_STATUS_CHANGED",
        entityType: "Booking",
        entityId: payment.booking.id,
        detail: { from: "PENDING_PAYMENT", to: "CONFIRMED", via: "payment" },
      });
    }

    if (payment.order && payment.order.status === "PENDING_PAYMENT") {
      // US-08 AC1: decrement stock only on successful payment, guarded so
      // stock can never go negative even under concurrent purchases.
      for (const item of payment.order.items) {
        const result = await tx.product.updateMany({
          where: { id: item.productId, stockQty: { gte: item.quantity } },
          data: { stockQty: { decrement: item.quantity } },
        });
        if (result.count === 0) {
          // Paid but out of stock: needs a manual refund — flag loudly.
          logger.error(
            { orderId: payment.order.id, productId: item.productId },
            "Paid order exceeds available stock — refund required",
          );
          await tx.order.update({
            where: { id: payment.order.id },
            data: { status: "CANCELLED" },
          });
          await audit(tx, {
            action: "ORDER_REFUND_REQUIRED",
            entityType: "Order",
            entityId: payment.order.id,
            detail: { reference, productId: item.productId },
          });
          return;
        }
        await audit(tx, {
          action: "STOCK_ADJUSTED",
          entityType: "Product",
          entityId: item.productId,
          detail: { change: -item.quantity, orderId: payment.order.id, via: "sale" },
        });
      }
      await tx.order.update({ where: { id: payment.order.id }, data: { status: "PAID" } });
    }
  });
}
