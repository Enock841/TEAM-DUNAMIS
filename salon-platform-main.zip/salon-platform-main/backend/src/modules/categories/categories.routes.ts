/**
 * Service-category endpoints (US-06). A category groups services and owns
 * the `dailyCap` — the maximum bookings accepted per day across all of its
 * services — which drives the availability rules in the bookings module.
 */
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { requireAdmin } from "../../middleware/auth";
import { validateBody } from "../../middleware/validate";

const categorySchema = z.object({
  name: z.string().trim().min(2).max(60),
  dailyCap: z.number().int().min(1).max(100),
});

export const categoriesRouter = Router();

// Public: the frontend groups the service list by these categories
categoriesRouter.get("/", async (_req, res) => {
  const categories = await prisma.serviceCategory.findMany({
    where: { deletedAt: null },
    orderBy: { name: "asc" },
    select: { id: true, name: true, dailyCap: true },
  });
  res.json(categories);
});

// US-06 AC1: admin creates categories
categoriesRouter.post("/", requireAdmin, validateBody(categorySchema), async (req, res) => {
  const category = await prisma.serviceCategory.create({ data: req.body });
  res.status(201).json({ category });
});

// US-06 AC2: admin changes name/daily cap. Existing confirmed bookings are
// untouched — the cap only gates *new* bookings (US-06 AC3).
categoriesRouter.put(
  "/:id",
  requireAdmin,
  validateBody(categorySchema.partial()),
  async (req, res) => {
    const existing = await prisma.serviceCategory.findFirst({
      where: { id: param(req, "id"), deletedAt: null },
    });
    if (!existing) throw ApiError.notFound("Category not found");
    const category = await prisma.serviceCategory.update({
      where: { id: existing.id },
      data: req.body,
    });
    res.json({ category });
  },
);

// Soft delete; blocked while services still reference the category so
// existing bookings never lose their category context.
categoriesRouter.delete("/:id", requireAdmin, async (req, res) => {
  const existing = await prisma.serviceCategory.findFirst({
    where: { id: param(req, "id"), deletedAt: null },
    include: { services: { where: { deletedAt: null }, select: { id: true } } },
  });
  if (!existing) throw ApiError.notFound("Category not found");
  if (existing.services.length > 0) {
    throw ApiError.conflict("Move or delete this category's services first");
  }
  await prisma.serviceCategory.update({
    where: { id: existing.id },
    data: { deletedAt: new Date() },
  });
  res.status(204).end();
});
