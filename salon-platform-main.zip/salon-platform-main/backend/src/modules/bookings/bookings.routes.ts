/**
 * Booking endpoints (US-04 create, US-05 availability, US-11 admin views).
 * All capacity/business rules live in bookings.service.ts — these handlers
 * only do auth, validation, and response shaping.
 */
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { audit } from "../../lib/audit";
import { requireAuth, requireAdmin } from "../../middleware/auth";
import { validateBody, validateQuery, parsedQuery } from "../../middleware/validate";
import { createBooking, getAvailability, parseDateOnly } from "./bookings.service";

const availabilityQuery = z.object({
  serviceId: z.uuid(),
  date: z.string(),
});

const createBookingSchema = z.object({
  serviceId: z.uuid(),
  date: z.string(),
  timeSlot: z.string(),
  notes: z.string().trim().max(500).optional(),
});

const statusSchema = z.object({
  status: z.enum(["CONFIRMED", "COMPLETED", "CANCELLED", "NO_SHOW"]),
});

// Relations attached to every booking response
const bookingInclude = {
  service: {
    select: {
      id: true,
      name: true,
      priceMin: true,
      priceMax: true,
      category: { select: { id: true, name: true } },
    },
  },
} as const;

export const bookingsRouter = Router();

// US-05: public availability check
bookingsRouter.get("/availability", validateQuery(availabilityQuery), async (req, res) => {
  const { serviceId, date } = parsedQuery<z.infer<typeof availabilityQuery>>(req);
  res.json(await getAvailability(serviceId, date));
});

// US-04: create booking (requires account, per documented assumption)
bookingsRouter.post("/", requireAuth, validateBody(createBookingSchema), async (req, res) => {
  const body = req.body as z.infer<typeof createBookingSchema>;
  const booking = await createBooking({ userId: req.user!.id, ...body });
  res.status(201).json({
    booking,
    // Customer pays the service's base price online to confirm the booking
    payment: { amountMinor: booking.service.priceMin, currency: "GHS" },
  });
});

// US-02 AC3: customer's own booking history
bookingsRouter.get("/me", requireAuth, async (req, res) => {
  const bookings = await prisma.booking.findMany({
    where: { userId: req.user!.id },
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    include: bookingInclude,
  });
  res.json(bookings);
});

// US-11: admin appointments view with customer details
bookingsRouter.get(
  "/",
  requireAdmin,
  validateQuery(
    z.object({
      date: z.string().optional(),
      categoryId: z.uuid().optional(),
      status: z.string().optional(),
    }),
  ),
  async (req, res) => {
    const q = parsedQuery<{ date?: string; categoryId?: string; status?: string }>(req);
    const bookings = await prisma.booking.findMany({
      where: {
        ...(q.date ? { date: parseDateOnly(q.date) } : {}),
        ...(q.categoryId ? { service: { categoryId: q.categoryId } } : {}),
        ...(q.status ? { status: q.status as never } : {}),
      },
      orderBy: [{ date: "asc" }, { timeSlot: "asc" }],
      include: {
        ...bookingInclude,
        user: { select: { id: true, name: true, phone: true, email: true } },
      },
    });
    res.json(bookings);
  },
);

// Admin: update booking status (confirm/complete/cancel/no-show)
bookingsRouter.put("/:id/status", requireAdmin, validateBody(statusSchema), async (req, res) => {
  const { status } = req.body as z.infer<typeof statusSchema>;
  const existing = await prisma.booking.findUnique({ where: { id: param(req, "id") } });
  if (!existing) throw ApiError.notFound("Booking not found");

  const booking = await prisma.$transaction(async (tx) => {
    const updated = await tx.booking.update({
      where: { id: existing.id },
      data: { status },
      include: bookingInclude,
    });
    await audit(tx, {
      actorId: req.user!.id,
      action: "BOOKING_STATUS_CHANGED",
      entityType: "Booking",
      entityId: existing.id,
      detail: { from: existing.status, to: status },
    });
    return updated;
  });

  res.json({ booking });
});
