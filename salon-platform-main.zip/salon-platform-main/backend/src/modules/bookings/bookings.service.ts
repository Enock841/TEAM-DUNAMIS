/**
 * Booking domain logic — the core of the product (US-04/05/06).
 *
 * The invariant defended here: for any (category, date), the number of
 * live bookings never exceeds the category's dailyCap, even when many
 * customers race for the last slot from different API instances. See
 * createBooking() for the locking strategy.
 *
 * Dates are treated as calendar days in UTC ("YYYY-MM-DD"): the salon
 * operates in a single timezone (Ghana = UTC), so day boundaries align.
 */
import { Prisma } from "@prisma/client";
import { prisma } from "../../lib/prisma";
import { ApiError } from "../../lib/errors";
import { env } from "../../config/env";

/** Time slots offered to customers. One booking occupies one slot. */
export const TIME_SLOTS = [
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
] as const;

/** Statuses that occupy a cap slot for their day. */
const CAP_STATUSES = ["PENDING_PAYMENT", "CONFIRMED", "COMPLETED"] as const;

/** Parse a strict "YYYY-MM-DD" string into a UTC-midnight Date, or 400. */
export function parseDateOnly(value: string): Date {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw ApiError.badRequest("Date must be in YYYY-MM-DD format");
  }
  const date = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(date.getTime())) throw ApiError.badRequest("Invalid date");
  return date;
}

function startOfTodayUtc(): Date {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

/**
 * US-04 AC2: bookings must be at least `bookingMinAdvanceDays` ahead
 * (default 2, env-configurable pending final client confirmation).
 */
export function assertMeetsAdvanceWindow(date: Date): void {
  const minDate = startOfTodayUtc();
  minDate.setUTCDate(minDate.getUTCDate() + env.bookingMinAdvanceDays);
  if (date < minDate) {
    throw ApiError.badRequest(
      `Bookings must be made at least ${env.bookingMinAdvanceDays} day(s) in advance`,
      "TOO_SOON",
    );
  }
}

/**
 * Unpaid bookings hold a cap slot only for a limited window; after that
 * they are cancelled so they stop blocking real customers.
 */
export async function expireStalePendingBookings(db: Prisma.TransactionClient | typeof prisma) {
  const cutoff = new Date(Date.now() - env.pendingBookingTtlMinutes * 60_000);
  await db.booking.updateMany({
    where: { status: "PENDING_PAYMENT", createdAt: { lt: cutoff } },
    data: { status: "CANCELLED" },
  });
}

/** How many cap-occupying bookings exist for a category on a given day. */
async function countCapUsage(
  db: Prisma.TransactionClient | typeof prisma,
  categoryId: string,
  date: Date,
): Promise<number> {
  return db.booking.count({
    where: {
      date,
      status: { in: [...CAP_STATUSES] },
      service: { categoryId },
    },
  });
}

/**
 * US-05: availability for a service on a date, driven by the service
 * category's daily cap. Also reports which time slots are taken for the
 * service so the UI can grey them out.
 */
export async function getAvailability(serviceId: string, dateStr: string) {
  const date = parseDateOnly(dateStr);
  const service = await prisma.service.findFirst({
    where: { id: serviceId, active: true, deletedAt: null },
    include: { category: true },
  });
  if (!service) throw ApiError.notFound("Service not found");

  await expireStalePendingBookings(prisma);

  const [capUsed, serviceBookings] = await Promise.all([
    countCapUsage(prisma, service.categoryId, date),
    prisma.booking.findMany({
      where: { serviceId, date, status: { in: [...CAP_STATUSES] } },
      select: { timeSlot: true },
    }),
  ]);

  const takenSlots = new Set(serviceBookings.map((b) => b.timeSlot));
  const slotsRemaining = Math.max(0, service.category.dailyCap - capUsed);

  let meetsAdvanceWindow = true;
  try {
    assertMeetsAdvanceWindow(date);
  } catch {
    meetsAdvanceWindow = false;
  }

  return {
    date: dateStr,
    dailyCap: service.category.dailyCap,
    slotsRemaining,
    available: slotsRemaining > 0 && meetsAdvanceWindow,
    minAdvanceDays: env.bookingMinAdvanceDays,
    timeSlots: TIME_SLOTS.map((slot) => ({
      slot,
      available: slotsRemaining > 0 && meetsAdvanceWindow && !takenSlots.has(slot),
    })),
  };
}

/**
 * US-04/US-05: create a booking, atomically enforcing the category's
 * daily cap. The category row is locked (SELECT ... FOR UPDATE) so two
 * simultaneous requests for the last slot serialize — one wins, one gets
 * a 409 — even across multiple server instances.
 */
export async function createBooking(input: {
  userId: string;
  serviceId: string;
  date: string;
  timeSlot: string;
  notes?: string;
}) {
  const date = parseDateOnly(input.date);
  assertMeetsAdvanceWindow(date);

  if (!TIME_SLOTS.includes(input.timeSlot as (typeof TIME_SLOTS)[number])) {
    throw ApiError.badRequest("Unknown time slot");
  }

  const service = await prisma.service.findFirst({
    where: { id: input.serviceId, active: true, deletedAt: null },
    include: { category: true },
  });
  if (!service) throw ApiError.notFound("Service not found");

  return prisma.$transaction(
    async (tx) => {
      // Serialize cap checks per category
      await tx.$queryRaw`SELECT id FROM service_categories WHERE id = ${service.categoryId} FOR UPDATE`;

      await expireStalePendingBookings(tx);

      const capUsed = await countCapUsage(tx, service.categoryId, date);
      if (capUsed >= service.category.dailyCap) {
        throw ApiError.conflict(
          "This date is fully booked for this service category. Please pick another date.",
          "DAILY_CAP_REACHED",
        );
      }

      const slotTaken = await tx.booking.findFirst({
        where: {
          serviceId: service.id,
          date,
          timeSlot: input.timeSlot,
          status: { in: ["PENDING_PAYMENT", "CONFIRMED", "COMPLETED"] },
        },
      });
      if (slotTaken) {
        throw ApiError.conflict("That time slot was just taken. Please pick another.", "SLOT_TAKEN");
      }

      return tx.booking.create({
        data: {
          userId: input.userId,
          serviceId: service.id,
          date,
          timeSlot: input.timeSlot,
          notes: input.notes,
        },
        include: {
          service: { select: { id: true, name: true, priceMin: true, priceMax: true } },
        },
      });
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.ReadCommitted },
  );
}
