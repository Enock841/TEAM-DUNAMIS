/**
 * Admin image uploads (service/product photos). Images live in Postgres —
 * plenty at MVP scale — so the app needs no object-storage account, and
 * they ride along in every database backup. Rows are immutable, so the
 * public GET can cache forever.
 */
import { Router } from "express";
import multer from "multer";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { requireAdmin } from "../../middleware/auth";

const MAX_BYTES = 5 * 1024 * 1024;
const ALLOWED_MIMES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES, files: 1 },
});

export const uploadsRouter = Router();

uploadsRouter.post(
  "/",
  requireAdmin,
  (req, res, next) => {
    upload.single("image")(req, res, (err: unknown) => {
      if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
        next(ApiError.badRequest("Image must be 5MB or smaller"));
      } else if (err) {
        next(ApiError.badRequest("Could not read the uploaded file"));
      } else {
        next();
      }
    });
  },
  async (req, res) => {
    const file = req.file;
    if (!file) throw ApiError.badRequest('Attach an image file in the "image" field');
    if (!ALLOWED_MIMES.has(file.mimetype)) {
      throw ApiError.badRequest("Only JPEG, PNG, WebP, or GIF images are allowed");
    }

    const image = await prisma.image.create({
      data: { mime: file.mimetype, data: new Uint8Array(file.buffer) },
      select: { id: true },
    });

    // trust proxy is on, so req.protocol reflects X-Forwarded-Proto
    const url = `${req.protocol}://${req.get("host")}/api/uploads/${image.id}`;
    res.status(201).json({ id: image.id, url });
  },
);

uploadsRouter.get("/:id", async (req, res) => {
  const image = await prisma.image.findUnique({ where: { id: param(req, "id") } });
  if (!image) throw ApiError.notFound("Image not found");

  res
    .setHeader("Content-Type", image.mime)
    // Helmet defaults to same-origin, which would stop the storefront
    // (different origin) from rendering these images
    .setHeader("Cross-Origin-Resource-Policy", "cross-origin")
    .setHeader("Cache-Control", "public, max-age=31536000, immutable")
    .send(Buffer.from(image.data));
});
