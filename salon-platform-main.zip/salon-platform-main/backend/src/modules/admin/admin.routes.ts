/**
 * Admin-only endpoints: dashboard stats (US-11), customer profiles and
 * history (US-12), and the audit-log viewer (NFR-07). The whole router is
 * gated by requireAdmin — nothing here is reachable by customers.
 */
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { requireAdmin } from "../../middleware/auth";
import { validateQuery, parsedQuery } from "../../middleware/validate";

export const adminRouter = Router();

// Every route below requires the ADMIN role (US-12 AC3, NFR-06)
adminRouter.use(requireAdmin);

// Dashboard overview numbers (US-11)
adminRouter.get("/stats", async (_req, res) => {
  const todayUtc = new Date();
  const today = new Date(
    Date.UTC(todayUtc.getUTCFullYear(), todayUtc.getUTCMonth(), todayUtc.getUTCDate()),
  );

  const [bookingsToday, upcomingBookings, pendingOrders, lowStock, customers, revenue] =
    await Promise.all([
      prisma.booking.count({ where: { date: today, status: { not: "CANCELLED" } } }),
      prisma.booking.count({ where: { date: { gte: today }, status: "CONFIRMED" } }),
      prisma.order.count({ where: { status: "PAID" } }),
      prisma.product.count({ where: { deletedAt: null, active: true, stockQty: { lte: 5 } } }),
      prisma.user.count({ where: { role: "CUSTOMER", deletedAt: null } }),
      prisma.payment.aggregate({ where: { status: "SUCCESS" }, _sum: { amountMinor: true } }),
    ]);

  res.json({
    bookingsToday,
    upcomingBookings,
    ordersAwaitingFulfilment: pendingOrders,
    lowStockProducts: lowStock,
    totalCustomers: customers,
    totalRevenueMinor: revenue._sum.amountMinor ?? 0,
  });
});

// US-12 AC1/AC3: admin-only customer search and list
adminRouter.get(
  "/customers",
  validateQuery(z.object({ search: z.string().trim().optional() })),
  async (req, res) => {
    const { search } = parsedQuery<{ search?: string }>(req);
    const customers = await prisma.user.findMany({
      where: {
        role: "CUSTOMER",
        deletedAt: null,
        ...(search
          ? {
              OR: [
                { name: { contains: search, mode: "insensitive" } },
                { phone: { contains: search } },
                { email: { contains: search, mode: "insensitive" } },
              ],
            }
          : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 100,
      select: {
        id: true,
        name: true,
        phone: true,
        email: true,
        createdAt: true,
        _count: { select: { bookings: true, orders: true } },
      },
    });
    res.json(customers);
  },
);

// US-12 AC2: full profile with retained history
adminRouter.get("/customers/:id", async (req, res) => {
  const customer = await prisma.user.findFirst({
    where: { id: param(req, "id"), role: "CUSTOMER", deletedAt: null },
    select: {
      id: true,
      name: true,
      phone: true,
      email: true,
      createdAt: true,
      bookings: {
        orderBy: { date: "desc" },
        include: { service: { select: { name: true, category: { select: { name: true } } } } },
      },
      orders: {
        orderBy: { createdAt: "desc" },
        include: { items: { include: { product: { select: { name: true } } } } },
      },
    },
  });
  if (!customer) throw ApiError.notFound("Customer not found");
  res.json(customer);
});

// NFR-07: audit trail viewer
adminRouter.get("/audit-logs", async (_req, res) => {
  const logs = await prisma.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { actor: { select: { id: true, name: true, role: true } } },
  });
  res.json(logs);
});
