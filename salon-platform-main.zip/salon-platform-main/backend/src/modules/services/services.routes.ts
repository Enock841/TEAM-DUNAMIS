/**
 * Service catalog endpoints (US-03 public browsing, admin CRUD via US-11).
 * Prices are stored as a min–max range in pesewas; the final price within
 * the range is agreed at the salon. Deletes are soft so historical
 * bookings keep their service reference.
 */
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { requireAdmin } from "../../middleware/auth";
import { validateBody } from "../../middleware/validate";

const serviceBase = z.object({
  name: z.string().trim().min(2).max(100),
  description: z.string().trim().max(2000).default(""),
  categoryId: z.uuid(),
  priceMin: z.number().int().min(0),
  priceMax: z.number().int().min(0),
  imageUrl: z.url().nullish(),
  active: z.boolean().default(true),
});

// Shared price-range rule, tolerant of partial updates where only one
// bound is present (Zod 4 forbids .partial() after .refine(), hence the split)
const priceRangeValid = {
  check: (s: { priceMin?: number; priceMax?: number }) =>
    s.priceMin === undefined || s.priceMax === undefined || s.priceMax >= s.priceMin,
  message: "priceMax must be greater than or equal to priceMin",
};

const serviceSchema = serviceBase.refine(priceRangeValid.check, {
  message: priceRangeValid.message,
  path: ["priceMax"],
});

const serviceUpdateSchema = serviceBase.partial().refine(priceRangeValid.check, {
  message: priceRangeValid.message,
  path: ["priceMax"],
});

// Single source of truth for the service shape returned to clients
const serviceSelect = {
  id: true,
  name: true,
  description: true,
  priceMin: true,
  priceMax: true,
  imageUrl: true,
  active: true,
  category: { select: { id: true, name: true, dailyCap: true } },
} as const;

export const servicesRouter = Router();

// US-03: public list — inactive/deleted services hidden (AC3)
servicesRouter.get("/", async (req, res) => {
  const categoryId = typeof req.query.categoryId === "string" ? req.query.categoryId : undefined;
  const services = await prisma.service.findMany({
    where: { active: true, deletedAt: null, ...(categoryId ? { categoryId } : {}) },
    orderBy: [{ category: { name: "asc" } }, { name: "asc" }],
    select: serviceSelect,
  });
  res.json(services);
});

// Admin list including inactive services
servicesRouter.get("/all", requireAdmin, async (_req, res) => {
  const services = await prisma.service.findMany({
    where: { deletedAt: null },
    orderBy: [{ category: { name: "asc" } }, { name: "asc" }],
    select: serviceSelect,
  });
  res.json(services);
});

servicesRouter.get("/:id", async (req, res) => {
  const service = await prisma.service.findFirst({
    where: { id: param(req, "id"), active: true, deletedAt: null },
    select: serviceSelect,
  });
  if (!service) throw ApiError.notFound("Service not found");
  res.json(service);
});

servicesRouter.post("/", requireAdmin, validateBody(serviceSchema), async (req, res) => {
  const data = req.body as z.infer<typeof serviceSchema>;
  const category = await prisma.serviceCategory.findFirst({
    where: { id: data.categoryId, deletedAt: null },
  });
  if (!category) throw ApiError.badRequest("Unknown categoryId");
  const service = await prisma.service.create({
    data: { ...data, imageUrl: data.imageUrl ?? null },
    select: serviceSelect,
  });
  res.status(201).json({ service });
});

servicesRouter.put(
  "/:id",
  requireAdmin,
  validateBody(serviceUpdateSchema),
  async (req, res) => {
    const existing = await prisma.service.findFirst({
      where: { id: param(req, "id"), deletedAt: null },
    });
    if (!existing) throw ApiError.notFound("Service not found");
    const service = await prisma.service.update({
      where: { id: existing.id },
      data: req.body,
      select: serviceSelect,
    });
    res.json({ service });
  },
);

servicesRouter.delete("/:id", requireAdmin, async (req, res) => {
  const existing = await prisma.service.findFirst({
    where: { id: param(req, "id"), deletedAt: null },
  });
  if (!existing) throw ApiError.notFound("Service not found");
  await prisma.service.update({
    where: { id: existing.id },
    data: { deletedAt: new Date(), active: false },
  });
  res.status(204).end();
});
