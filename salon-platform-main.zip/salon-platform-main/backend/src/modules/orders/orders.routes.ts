/**
 * Order endpoints (US-07 checkout, admin order management via US-11).
 * Totals are always computed server-side from the live catalog — client
 * prices are never trusted. Unit prices are copied onto each order item
 * so later catalog price changes never rewrite purchase history.
 */
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma";
import { param } from "../../lib/params";
import { ApiError } from "../../lib/errors";
import { requireAuth, requireAdmin } from "../../middleware/auth";
import { validateBody, validateQuery, parsedQuery } from "../../middleware/validate";

const createOrderSchema = z.object({
  items: z
    .array(
      z.object({
        productId: z.uuid(),
        quantity: z.number().int().min(1).max(50),
      }),
    )
    .min(1, "Cart is empty"),
});

const orderInclude = {
  items: {
    include: { product: { select: { id: true, name: true, imageUrl: true } } },
  },
} as const;

export const ordersRouter = Router();

// US-07: checkout — order created pending payment; stock is deducted
// only after successful payment (US-08), with a hard guard against
// overselling at payment time.
ordersRouter.post("/", requireAuth, validateBody(createOrderSchema), async (req, res) => {
  const { items } = req.body as z.infer<typeof createOrderSchema>;

  // Merge duplicate product lines (e.g. same item added twice) into one quantity
  const quantities = new Map<string, number>();
  for (const item of items) {
    quantities.set(item.productId, (quantities.get(item.productId) ?? 0) + item.quantity);
  }
  const productIds = [...quantities.keys()];

  const products = await prisma.product.findMany({
    where: { id: { in: productIds }, active: true, deletedAt: null },
  });
  if (products.length !== productIds.length) {
    throw ApiError.badRequest("One or more products are unavailable");
  }
  for (const product of products) {
    const qty = quantities.get(product.id)!;
    if (product.stockQty < qty) {
      throw ApiError.conflict(
        `Only ${product.stockQty} of "${product.name}" left in stock`,
        "INSUFFICIENT_STOCK",
      );
    }
  }

  const totalMinor = products.reduce((sum, p) => sum + p.price * quantities.get(p.id)!, 0);

  const order = await prisma.order.create({
    data: {
      userId: req.user!.id,
      totalMinor,
      items: {
        create: products.map((p) => ({
          productId: p.id,
          quantity: quantities.get(p.id)!,
          unitPriceMinor: p.price,
        })),
      },
    },
    include: orderInclude,
  });

  res.status(201).json({ order, payment: { amountMinor: totalMinor, currency: "GHS" } });
});

ordersRouter.get("/me", requireAuth, async (req, res) => {
  const orders = await prisma.order.findMany({
    where: { userId: req.user!.id },
    orderBy: { createdAt: "desc" },
    include: orderInclude,
  });
  res.json(orders);
});

ordersRouter.get(
  "/",
  requireAdmin,
  validateQuery(z.object({ status: z.string().optional() })),
  async (req, res) => {
    const q = parsedQuery<{ status?: string }>(req);
    const orders = await prisma.order.findMany({
      where: q.status ? { status: q.status as never } : {},
      orderBy: { createdAt: "desc" },
      include: {
        ...orderInclude,
        user: { select: { id: true, name: true, phone: true, email: true } },
      },
    });
    res.json(orders);
  },
);

// Admin: mark a paid order fulfilled / cancelled
ordersRouter.put(
  "/:id/status",
  requireAdmin,
  validateBody(z.object({ status: z.enum(["FULFILLED", "CANCELLED"]) })),
  async (req, res) => {
    const existing = await prisma.order.findUnique({ where: { id: param(req, "id") } });
    if (!existing) throw ApiError.notFound("Order not found");
    const order = await prisma.order.update({
      where: { id: existing.id },
      data: { status: (req.body as { status: "FULFILLED" | "CANCELLED" }).status },
      include: orderInclude,
    });
    res.json({ order });
  },
);
