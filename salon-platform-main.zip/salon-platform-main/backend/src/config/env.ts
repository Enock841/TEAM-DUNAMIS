/**
 * Central, validated view of all environment configuration.
 * Every env var the backend uses is read HERE and nowhere else, so the
 * full configuration surface is visible in one file. Missing required
 * values fail fast at boot instead of causing runtime surprises.
 */
import dotenv from "dotenv";

// Load .env into process.env (no-op in production where the platform injects vars)
dotenv.config();

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

export const env = {
  nodeEnv: process.env.NODE_ENV ?? "development",
  isProd: process.env.NODE_ENV === "production",
  isTest: process.env.NODE_ENV === "test",
  port: Number(process.env.PORT ?? 4000),
  databaseUrl: required("DATABASE_URL"),
  jwtSecret: required("JWT_SECRET"),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? "24h",
  corsOrigins: (process.env.CORS_ORIGIN ?? "http://localhost:3000")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean),
  paymentProvider: process.env.PAYMENT_PROVIDER ?? "mock",
  paystackSecretKey: process.env.PAYSTACK_SECRET_KEY ?? "",
  ownerMomoNumber: process.env.OWNER_MOMO_NUMBER ?? "",
  // US-04 AC2: bookings must be at least N days in advance (client-confirmable)
  bookingMinAdvanceDays: Number(process.env.BOOKING_MIN_ADVANCE_DAYS ?? 2),
  // Pending (unpaid) bookings hold a cap slot for this long before expiring
  pendingBookingTtlMinutes: Number(process.env.PENDING_BOOKING_TTL_MINUTES ?? 30),
};
