/**
 * Application error carrying an HTTP status and a stable machine-readable
 * code. Route handlers throw these; the error middleware converts them to
 * the uniform `{ error: { code, message } }` JSON response shape.
 */
export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly code?: string,
  ) {
    super(message);
    this.name = "ApiError";
  }

  static badRequest(message: string, code = "BAD_REQUEST") {
    return new ApiError(400, message, code);
  }
  static unauthorized(message = "Authentication required", code = "UNAUTHORIZED") {
    return new ApiError(401, message, code);
  }
  static forbidden(message = "You do not have permission to do this", code = "FORBIDDEN") {
    return new ApiError(403, message, code);
  }
  static notFound(message = "Resource not found", code = "NOT_FOUND") {
    return new ApiError(404, message, code);
  }
  static conflict(message: string, code = "CONFLICT") {
    return new ApiError(409, message, code);
  }
}
