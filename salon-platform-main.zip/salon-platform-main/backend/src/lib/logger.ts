import pino from "pino";

/**
 * Structured JSON logger (pino). JSON output is what Railway/most log
 * aggregators parse best; silenced during tests to keep output readable.
 */
export const logger = pino({
  level: process.env.LOG_LEVEL ?? (process.env.NODE_ENV === "test" ? "silent" : "info"),
});
