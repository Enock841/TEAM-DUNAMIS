import type { Request } from "express";
import { ApiError } from "./errors";

/** Express 5 types path params as string | string[]; normalize to string. */
export function param(req: Request, name: string): string {
  const value = (req.params as Record<string, string | string[] | undefined>)[name];
  if (typeof value === "string" && value.length > 0) return value;
  throw ApiError.badRequest(`Missing route parameter: ${name}`);
}
