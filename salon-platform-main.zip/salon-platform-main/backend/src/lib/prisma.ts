import { PrismaClient } from "@prisma/client";

/**
 * Single shared PrismaClient for the whole process. Prisma manages its own
 * connection pool, so one instance is both sufficient and required —
 * constructing clients per-request would exhaust database connections.
 */
export const prisma = new PrismaClient();
