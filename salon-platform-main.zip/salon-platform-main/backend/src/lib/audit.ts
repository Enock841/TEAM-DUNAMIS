import type { Prisma, PrismaClient } from "@prisma/client";

type Db = PrismaClient | Prisma.TransactionClient;

/**
 * NFR-07: record stock adjustments, payment transactions, and booking
 * status changes with timestamp and acting user (actorId null = system).
 * Accepts a transaction client so audit rows commit atomically with the
 * change they describe.
 */
export async function audit(
  db: Db,
  entry: {
    actorId?: string | null;
    action: string;
    entityType: string;
    entityId: string;
    detail?: Prisma.InputJsonValue;
  },
): Promise<void> {
  await db.auditLog.create({
    data: {
      actorId: entry.actorId ?? null,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId,
      detail: entry.detail,
    },
  });
}
