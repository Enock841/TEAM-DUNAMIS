/**
 * JWT authentication + role-based authorization middleware (ADR-004).
 *
 * Tokens are issued at register/login, carried by clients in the
 * `Authorization: Bearer <token>` header, and verified here on every
 * protected route. The decoded identity is attached as `req.user`.
 */
import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/env";
import { ApiError } from "../lib/errors";

export interface AuthUser {
  id: string;
  role: "CUSTOMER" | "ADMIN";
  name: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

/** Issue a signed JWT carrying the user's id, role, and display name. */
export function signToken(user: { id: string; role: string; name: string }): string {
  return jwt.sign({ sub: user.id, role: user.role, name: user.name }, env.jwtSecret, {
    expiresIn: env.jwtExpiresIn,
  } as jwt.SignOptions);
}

/** Parse and verify the Bearer token; null for missing/invalid/expired tokens. */
function extractUser(req: Request): AuthUser | null {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) return null;
  try {
    const payload = jwt.verify(header.slice(7), env.jwtSecret) as jwt.JwtPayload;
    if (!payload.sub || !payload.role) return null;
    return { id: String(payload.sub), role: payload.role, name: String(payload.name ?? "") };
  } catch {
    return null;
  }
}

/** Attaches req.user when a valid token is present; never rejects. */
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const user = extractUser(req);
  if (user) req.user = user;
  next();
}

/** Rejects with 401 unless a valid token is presented (any role). */
export function requireAuth(req: Request, _res: Response, next: NextFunction) {
  const user = extractUser(req);
  if (!user) throw ApiError.unauthorized();
  req.user = user;
  next();
}

/** Rejects with 401 (no token) or 403 (not the salon owner/admin role). */
export function requireAdmin(req: Request, _res: Response, next: NextFunction) {
  const user = extractUser(req);
  if (!user) throw ApiError.unauthorized();
  if (user.role !== "ADMIN") throw ApiError.forbidden();
  req.user = user;
  next();
}
