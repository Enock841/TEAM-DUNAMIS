/**
 * Global error handling. Every error thrown anywhere in the request
 * pipeline funnels here (Express 5 forwards rejected async handlers
 * automatically) and is translated into the uniform JSON error shape:
 *   { error: { code, message, details? } }
 * Internal messages are hidden in production to avoid leaking details.
 */
import type { NextFunction, Request, Response } from "express";
import { ZodError } from "zod";
import { Prisma } from "@prisma/client";
import { ApiError } from "../lib/errors";
import { logger } from "../lib/logger";
import { env } from "../config/env";

export function notFoundHandler(_req: Request, res: Response) {
  res.status(404).json({ error: { code: "NOT_FOUND", message: "Endpoint not found" } });
}

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ApiError) {
    res.status(err.status).json({ error: { code: err.code, message: err.message } });
    return;
  }

  if (err instanceof ZodError) {
    res.status(400).json({
      error: {
        code: "VALIDATION_ERROR",
        message: "Invalid request data",
        details: err.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
      },
    });
    return;
  }

  // Unique constraint violations surface as conflicts (e.g. duplicate phone)
  if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
    res.status(409).json({
      error: { code: "CONFLICT", message: "A record with these details already exists" },
    });
    return;
  }

  logger.error({ err }, "Unhandled error");
  res.status(500).json({
    error: {
      code: "INTERNAL_ERROR",
      message: env.isProd ? "Something went wrong" : String((err as Error)?.message ?? err),
    },
  });
}
