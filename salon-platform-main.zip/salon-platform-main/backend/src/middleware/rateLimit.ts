/**
 * Rate limiting: a generous general limit for the whole API plus a much
 * stricter one on credential endpoints to slow brute-force login attempts.
 * Effectively disabled under test so suites can hammer the API freely.
 */
import rateLimit from "express-rate-limit";
import { env } from "../config/env";

const disabled = env.isTest;

/** General API limiter — generous, protects against runaway clients. */
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: disabled ? 100_000 : 300,
  standardHeaders: "draft-7",
  legacyHeaders: false,
});

/** Strict limiter for credential endpoints (login/register). */
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: disabled ? 100_000 : 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: { code: "RATE_LIMITED", message: "Too many attempts, try again later" } },
});
