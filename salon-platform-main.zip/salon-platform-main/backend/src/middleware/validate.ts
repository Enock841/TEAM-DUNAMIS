/**
 * Zod-based request validation middleware. Schemas are declared next to
 * each route; anything that fails validation becomes a 400 with per-field
 * details (see error middleware) before the handler ever runs.
 */
import type { NextFunction, Request, Response } from "express";
import type { ZodType } from "zod";

/**
 * Validates and replaces req.body (or req.query) with the parsed result.
 * Throws ZodError, converted to a 400 response by the error middleware.
 */
export function validateBody(schema: ZodType) {
  return (req: Request, _res: Response, next: NextFunction) => {
    req.body = schema.parse(req.body ?? {});
    next();
  };
}

export function validateQuery(schema: ZodType) {
  return (req: Request, _res: Response, next: NextFunction) => {
    // Express 5 exposes req.query as a getter; store parsed result separately.
    (req as Request & { parsedQuery: unknown }).parsedQuery = schema.parse(req.query);
    next();
  };
}

/** Retrieve the query object previously validated by validateQuery(). */
export function parsedQuery<T>(req: Request): T {
  return (req as Request & { parsedQuery: T }).parsedQuery;
}
