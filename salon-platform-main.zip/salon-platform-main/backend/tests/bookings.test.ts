// Booking flow and daily-cap enforcement tests (US-04, US-05),
// including the concurrency race for the last remaining slot.
import { beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { prisma } from "../src/lib/prisma";
import { app, resetDb, createUser, createCatalog, futureDate } from "./helpers";

beforeEach(resetDb);

describe("Booking flow (US-04, US-05)", () => {
  it("books an available slot", async () => {
    const { token } = await createUser();
    const { service } = await createCatalog();

    const res = await request(app)
      .post("/api/bookings")
      .set("Authorization", `Bearer ${token}`)
      .send({ serviceId: service.id, date: futureDate(), timeSlot: "09:00" });

    expect(res.status).toBe(201);
    expect(res.body.booking.status).toBe("PENDING_PAYMENT");
    expect(res.body.payment.amountMinor).toBe(35000);
  });

  it("rejects bookings inside the 2-day advance window", async () => {
    const { token } = await createUser();
    const { service } = await createCatalog();
    const tomorrow = futureDate(1);

    const res = await request(app)
      .post("/api/bookings")
      .set("Authorization", `Bearer ${token}`)
      .send({ serviceId: service.id, date: tomorrow, timeSlot: "09:00" });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("TOO_SOON");
  });

  it("enforces the category daily cap (US-05)", async () => {
    const { token } = await createUser();
    const { service } = await createCatalog(3);
    const date = futureDate();

    for (const slot of ["08:00", "09:00", "10:00"]) {
      const res = await request(app)
        .post("/api/bookings")
        .set("Authorization", `Bearer ${token}`)
        .send({ serviceId: service.id, date, timeSlot: slot });
      expect(res.status).toBe(201);
    }

    const overCap = await request(app)
      .post("/api/bookings")
      .set("Authorization", `Bearer ${token}`)
      .send({ serviceId: service.id, date, timeSlot: "11:00" });

    expect(overCap.status).toBe(409);
    expect(overCap.body.error.code).toBe("DAILY_CAP_REACHED");

    // Another date in the same category is still open
    const otherDate = await request(app)
      .post("/api/bookings")
      .set("Authorization", `Bearer ${token}`)
      .send({ serviceId: service.id, date: futureDate(8), timeSlot: "09:00" });
    expect(otherDate.status).toBe(201);
  });

  it("only lets one of two concurrent requests take the last cap slot", async () => {
    const { token: t1 } = await createUser();
    const { token: t2 } = await createUser();
    const { service } = await createCatalog(1);
    const date = futureDate();

    const [a, b] = await Promise.all([
      request(app)
        .post("/api/bookings")
        .set("Authorization", `Bearer ${t1}`)
        .send({ serviceId: service.id, date, timeSlot: "09:00" }),
      request(app)
        .post("/api/bookings")
        .set("Authorization", `Bearer ${t2}`)
        .send({ serviceId: service.id, date, timeSlot: "10:00" }),
    ]);

    const statuses = [a.status, b.status].sort();
    expect(statuses).toEqual([201, 409]);
  });

  it("reports availability with per-slot detail", async () => {
    const { token } = await createUser();
    const { service } = await createCatalog(2);
    const date = futureDate();

    await request(app)
      .post("/api/bookings")
      .set("Authorization", `Bearer ${token}`)
      .send({ serviceId: service.id, date, timeSlot: "09:00" });

    const res = await request(app)
      .get("/api/bookings/availability")
      .query({ serviceId: service.id, date });

    expect(res.status).toBe(200);
    expect(res.body.slotsRemaining).toBe(1);
    expect(res.body.available).toBe(true);
    const nine = res.body.timeSlots.find((s: { slot: string }) => s.slot === "09:00");
    expect(nine.available).toBe(false);
  });

  it("frees the cap slot when a stale pending booking expires", async () => {
    const { token } = await createUser();
    const { service } = await createCatalog(1);
    const date = futureDate();

    await request(app)
      .post("/api/bookings")
      .set("Authorization", `Bearer ${token}`)
      .send({ serviceId: service.id, date, timeSlot: "09:00" });

    // Age the pending booking past the TTL
    await prisma.booking.updateMany({
      data: { createdAt: new Date(Date.now() - 60 * 60_000) },
    });

    const res = await request(app)
      .get("/api/bookings/availability")
      .query({ serviceId: service.id, date });
    expect(res.body.slotsRemaining).toBe(1);
  });
});
