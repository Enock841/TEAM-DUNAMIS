// Admin image upload + public serving
import { beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { app, resetDb, createUser } from "./helpers";

beforeEach(resetDb);

// Tiny valid PNG (1×1 transparent pixel)
const PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
  "base64",
);

describe("POST /api/uploads", () => {
  it("stores an image and serves it back publicly with caching", async () => {
    const { token } = await createUser({ role: "ADMIN" });

    const res = await request(app)
      .post("/api/uploads")
      .set("Authorization", `Bearer ${token}`)
      .attach("image", PNG, { filename: "pixel.png", contentType: "image/png" });

    expect(res.status).toBe(201);
    expect(res.body.url).toContain(`/api/uploads/${res.body.id}`);

    const img = await request(app).get(`/api/uploads/${res.body.id}`);
    expect(img.status).toBe(200);
    expect(img.headers["content-type"]).toBe("image/png");
    expect(img.headers["cross-origin-resource-policy"]).toBe("cross-origin");
    expect(img.headers["cache-control"]).toContain("immutable");
    expect(Buffer.compare(img.body as Buffer, PNG)).toBe(0);
  });

  it("rejects non-admins and anonymous callers", async () => {
    const { token } = await createUser();
    const asCustomer = await request(app)
      .post("/api/uploads")
      .set("Authorization", `Bearer ${token}`)
      .attach("image", PNG, { filename: "pixel.png", contentType: "image/png" });
    expect(asCustomer.status).toBe(403);

    const anon = await request(app)
      .post("/api/uploads")
      .attach("image", PNG, { filename: "pixel.png", contentType: "image/png" });
    expect(anon.status).toBe(401);
  });

  it("rejects non-image uploads and missing files", async () => {
    const { token } = await createUser({ role: "ADMIN" });

    const wrongType = await request(app)
      .post("/api/uploads")
      .set("Authorization", `Bearer ${token}`)
      .attach("image", Buffer.from("#!/bin/sh"), {
        filename: "script.sh",
        contentType: "application/x-sh",
      });
    expect(wrongType.status).toBe(400);

    const missing = await request(app)
      .post("/api/uploads")
      .set("Authorization", `Bearer ${token}`);
    expect(missing.status).toBe(400);
  });

  it("404s for an unknown image id", async () => {
    const res = await request(app).get(
      "/api/uploads/00000000-0000-0000-0000-000000000000",
    );
    expect(res.status).toBe(404);
  });
});
