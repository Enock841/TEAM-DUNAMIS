// Role-based access control and admin workflow tests (US-06, US-11, US-12, NFR-07)
import { beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { app, resetDb, createUser, createCatalog } from "./helpers";

beforeEach(resetDb);

describe("Role-based access control (US-06, US-11, US-12)", () => {
  it("blocks customers from admin endpoints", async () => {
    const { token } = await createUser();
    for (const path of ["/api/admin/customers", "/api/admin/stats", "/api/services/all"]) {
      const res = await request(app).get(path).set("Authorization", `Bearer ${token}`);
      expect(res.status, path).toBe(403);
    }
  });

  it("blocks unauthenticated admin mutations", async () => {
    const { category } = await createCatalog();
    const res = await request(app).put(`/api/categories/${category.id}`).send({ dailyCap: 99 });
    expect(res.status).toBe(401);
  });

  it("lets the admin update a category's daily cap (US-06)", async () => {
    const { token } = await createUser({ role: "ADMIN" });
    const { category } = await createCatalog(3);

    const res = await request(app)
      .put(`/api/categories/${category.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ dailyCap: 5 });

    expect(res.status).toBe(200);
    expect(res.body.category.dailyCap).toBe(5);
  });

  it("audits manual stock adjustments (US-08 AC3, NFR-07)", async () => {
    const { token } = await createUser({ role: "ADMIN" });
    const { product } = await createCatalog();

    const res = await request(app)
      .put(`/api/products/${product.id}/stock`)
      .set("Authorization", `Bearer ${token}`)
      .send({ stockQty: 50, reason: "restock delivery" });

    expect(res.status).toBe(200);
    expect(res.body.product.stockQty).toBe(50);

    const logs = await request(app)
      .get("/api/admin/audit-logs")
      .set("Authorization", `Bearer ${token}`);
    expect(logs.body.some((l: { action: string }) => l.action === "STOCK_ADJUSTED")).toBe(true);
  });

  it("lists customers with booking/order counts (US-12)", async () => {
    const { token } = await createUser({ role: "ADMIN" });
    await createUser({ name: "Ama Serwaa" });

    const res = await request(app)
      .get("/api/admin/customers")
      .query({ search: "Serwaa" })
      .set("Authorization", `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(1);
    expect(res.body[0].name).toBe("Ama Serwaa");
  });
});
