// Registration, login, and session tests (US-01, US-02)
import { beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { app, resetDb, createUser } from "./helpers";

beforeEach(resetDb);

describe("POST /api/auth/register (US-01)", () => {
  it("creates an account and returns a token", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "Ama Mensah", phone: "233241234567", password: "Password123" });

    expect(res.status).toBe(201);
    expect(res.body.token).toBeTruthy();
    expect(res.body.user).toMatchObject({ name: "Ama Mensah", role: "CUSTOMER" });
    expect(res.body.user.passwordHash).toBeUndefined();
  });

  it("rejects a duplicate phone number", async () => {
    await request(app)
      .post("/api/auth/register")
      .send({ name: "Ama", phone: "233241234567", password: "Password123" });
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "Another Ama", phone: "233241234567", password: "Password456" });

    expect(res.status).toBe(409);
  });

  it("rejects weak input", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "A", phone: "not-a-phone", password: "short" });
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("VALIDATION_ERROR");
  });
});

describe("POST /api/auth/login (US-02)", () => {
  it("logs in with phone + password", async () => {
    await request(app)
      .post("/api/auth/register")
      .send({ name: "Ama", phone: "233241234567", password: "Password123" });

    const res = await request(app)
      .post("/api/auth/login")
      .send({ identifier: "233241234567", password: "Password123" });

    expect(res.status).toBe(200);
    expect(res.body.token).toBeTruthy();
  });

  it("does not reveal which credential was wrong", async () => {
    await request(app)
      .post("/api/auth/register")
      .send({ name: "Ama", phone: "233241234567", password: "Password123" });

    const wrongPassword = await request(app)
      .post("/api/auth/login")
      .send({ identifier: "233241234567", password: "WrongPass1" });
    const unknownUser = await request(app)
      .post("/api/auth/login")
      .send({ identifier: "233209999999", password: "Password123" });

    expect(wrongPassword.status).toBe(401);
    expect(unknownUser.status).toBe(401);
    expect(wrongPassword.body.error.message).toBe(unknownUser.body.error.message);
  });
});

describe("GET /api/auth/me", () => {
  it("returns the authenticated user", async () => {
    const { token } = await createUser({ name: "Efua" });
    const res = await request(app).get("/api/auth/me").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.user.name).toBe("Efua");
  });

  it("rejects a missing token", async () => {
    const res = await request(app).get("/api/auth/me");
    expect(res.status).toBe(401);
  });
});

describe("PUT /api/auth/password", () => {
  it("changes the password and old one stops working", async () => {
    const { user, token } = await createUser({ name: "Akosua" });

    const res = await request(app)
      .put("/api/auth/password")
      .set("Authorization", `Bearer ${token}`)
      .send({ currentPassword: "Password123", newPassword: "NewSecret456" });
    expect(res.status).toBe(204);

    const oldLogin = await request(app)
      .post("/api/auth/login")
      .send({ identifier: user.phone, password: "Password123" });
    expect(oldLogin.status).toBe(401);

    const newLogin = await request(app)
      .post("/api/auth/login")
      .send({ identifier: user.phone, password: "NewSecret456" });
    expect(newLogin.status).toBe(200);
  });

  it("rejects a wrong current password", async () => {
    const { token } = await createUser();
    const res = await request(app)
      .put("/api/auth/password")
      .set("Authorization", `Bearer ${token}`)
      .send({ currentPassword: "WrongPass1", newPassword: "NewSecret456" });
    expect(res.status).toBe(401);
  });

  it("rejects a too-short new password and requires auth", async () => {
    const { token } = await createUser();
    const weak = await request(app)
      .put("/api/auth/password")
      .set("Authorization", `Bearer ${token}`)
      .send({ currentPassword: "Password123", newPassword: "short" });
    expect(weak.status).toBe(400);

    const anon = await request(app)
      .put("/api/auth/password")
      .send({ currentPassword: "Password123", newPassword: "NewSecret456" });
    expect(anon.status).toBe(401);
  });
});

describe("PUT /api/auth/me (profile update)", () => {
  it("updates name, phone, and email", async () => {
    const { user, token } = await createUser({ name: "Adjoa" });

    const res = await request(app)
      .put("/api/auth/me")
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "Adjoa Boateng", phone: "233541112222", email: "adjoa@example.com" });

    expect(res.status).toBe(200);
    expect(res.body.user).toMatchObject({
      id: user.id,
      name: "Adjoa Boateng",
      phone: "233541112222",
      email: "adjoa@example.com",
    });

    // New phone works as the login identifier
    const login = await request(app)
      .post("/api/auth/login")
      .send({ identifier: "233541112222", password: "Password123" });
    expect(login.status).toBe(200);
  });

  it("rejects a phone or email already taken by another account", async () => {
    const other = await createUser({ phone: "233549999999" });
    const { token } = await createUser();

    const res = await request(app)
      .put("/api/auth/me")
      .set("Authorization", `Bearer ${token}`)
      .send({ phone: other.user.phone });

    expect(res.status).toBe(409);
  });

  it("allows clearing the email and keeping own phone", async () => {
    const { user, token } = await createUser();
    const res = await request(app)
      .put("/api/auth/me")
      .set("Authorization", `Bearer ${token}`)
      .send({ phone: user.phone, email: null });
    expect(res.status).toBe(200);
    expect(res.body.user.email).toBeNull();
  });

  it("rejects invalid input and missing auth", async () => {
    const { token } = await createUser();
    const bad = await request(app)
      .put("/api/auth/me")
      .set("Authorization", `Bearer ${token}`)
      .send({ phone: "not-a-phone" });
    expect(bad.status).toBe(400);

    const anon = await request(app).put("/api/auth/me").send({ name: "Nope" });
    expect(anon.status).toBe(401);
  });
});
