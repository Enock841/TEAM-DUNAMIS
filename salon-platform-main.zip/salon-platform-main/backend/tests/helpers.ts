/**
 * Shared test utilities: one app instance, a full-DB reset between tests,
 * and factories for users and a minimal catalog. Tests run sequentially
 * (vitest fileParallelism=false) against the throwaway db_test container.
 */
import bcrypt from "bcryptjs";
import { prisma } from "../src/lib/prisma";
import { signToken } from "../src/middleware/auth";
import { createApp } from "../src/app";

export const app = createApp();

export async function resetDb() {
  await prisma.$executeRawUnsafe(`
    TRUNCATE TABLE images, audit_logs, payments, order_items, orders, bookings,
      products, services, service_categories, users RESTART IDENTITY CASCADE
  `);
}

export async function createUser(
  overrides: Partial<{ name: string; phone: string; role: "CUSTOMER" | "ADMIN" }> = {},
) {
  const user = await prisma.user.create({
    data: {
      name: overrides.name ?? "Test User",
      phone: overrides.phone ?? `2332${Math.floor(Math.random() * 1e8)}`,
      passwordHash: await bcrypt.hash("Password123", 4),
      role: overrides.role ?? "CUSTOMER",
    },
  });
  return { user, token: signToken(user) };
}

export async function createCatalog(dailyCap = 3) {
  const category = await prisma.serviceCategory.create({
    data: { name: `Tiny Braids ${Math.random()}`, dailyCap },
  });
  const service = await prisma.service.create({
    data: {
      name: "Knotless Tiny Braids",
      categoryId: category.id,
      priceMin: 35000,
      priceMax: 60000,
    },
  });
  const product = await prisma.product.create({
    data: { name: "Braid Sheen Spray", price: 4500, stockQty: 10 },
  });
  return { category, service, product };
}

/** A date safely beyond the min-advance-booking window. */
export function futureDate(daysAhead = 5): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + daysAhead);
  return d.toISOString().slice(0, 10);
}
