// Orders, payments, and stock-deduction tests (US-07, US-08, US-09):
// stock moves only after successful payment, and never below zero.
import { beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { prisma } from "../src/lib/prisma";
import { app, resetDb, createUser, createCatalog, futureDate } from "./helpers";

beforeEach(resetDb);

describe("Orders & stock (US-07, US-08)", () => {
  it("creates an order priced from the server-side catalog", async () => {
    const { token } = await createUser();
    const { product } = await createCatalog();

    const res = await request(app)
      .post("/api/orders")
      .set("Authorization", `Bearer ${token}`)
      .send({ items: [{ productId: product.id, quantity: 2 }] });

    expect(res.status).toBe(201);
    expect(res.body.order.totalMinor).toBe(9000);
    expect(res.body.order.status).toBe("PENDING_PAYMENT");
  });

  it("rejects orders that exceed stock", async () => {
    const { token } = await createUser();
    const { product } = await createCatalog(); // stockQty 10

    const res = await request(app)
      .post("/api/orders")
      .set("Authorization", `Bearer ${token}`)
      .send({ items: [{ productId: product.id, quantity: 11 }] });

    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe("INSUFFICIENT_STOCK");
  });

  it("deducts stock only after successful payment, with audit trail (US-08, NFR-07)", async () => {
    const { user, token } = await createUser();
    const { product } = await createCatalog();

    const orderRes = await request(app)
      .post("/api/orders")
      .set("Authorization", `Bearer ${token}`)
      .send({ items: [{ productId: product.id, quantity: 3 }] });
    const orderId = orderRes.body.order.id;

    // Stock untouched before payment
    let stocked = await prisma.product.findUniqueOrThrow({ where: { id: product.id } });
    expect(stocked.stockQty).toBe(10);

    const payRes = await request(app)
      .post("/api/payments/initiate")
      .set("Authorization", `Bearer ${token}`)
      .send({ type: "order", refId: orderId, momoNumber: user.phone });

    expect(payRes.status).toBe(201);
    expect(payRes.body.status).toBe("SUCCESS");

    stocked = await prisma.product.findUniqueOrThrow({ where: { id: product.id } });
    expect(stocked.stockQty).toBe(7);

    const order = await prisma.order.findUniqueOrThrow({ where: { id: orderId } });
    expect(order.status).toBe("PAID");

    const auditRows = await prisma.auditLog.findMany({ where: { action: "STOCK_ADJUSTED" } });
    expect(auditRows.length).toBe(1);
  });

  it("confirms a booking after successful payment (US-09)", async () => {
    const { user, token } = await createUser();
    const { service } = await createCatalog();

    const bookingRes = await request(app)
      .post("/api/bookings")
      .set("Authorization", `Bearer ${token}`)
      .send({ serviceId: service.id, date: futureDate(), timeSlot: "09:00" });
    const bookingId = bookingRes.body.booking.id;

    const payRes = await request(app)
      .post("/api/payments/initiate")
      .set("Authorization", `Bearer ${token}`)
      .send({ type: "booking", refId: bookingId, momoNumber: user.phone });

    expect(payRes.status).toBe(201);
    expect(payRes.body.amountMinor).toBe(35000);

    const booking = await prisma.booking.findUniqueOrThrow({ where: { id: bookingId } });
    expect(booking.status).toBe("CONFIRMED");
  });

  it("records a failed charge without touching the order or stock", async () => {
    const { user, token } = await createUser();
    const { product } = await createCatalog();
    process.env.MOCK_PAYMENT_OUTCOME = "failed";

    const orderRes = await request(app)
      .post("/api/orders")
      .set("Authorization", `Bearer ${token}`)
      .send({ items: [{ productId: product.id, quantity: 1 }] });

    const payRes = await request(app)
      .post("/api/payments/initiate")
      .set("Authorization", `Bearer ${token}`)
      .send({ type: "order", refId: orderRes.body.order.id, momoNumber: user.phone });

    delete process.env.MOCK_PAYMENT_OUTCOME;

    expect(payRes.body.status).toBe("FAILED");
    const order = await prisma.order.findUniqueOrThrow({ where: { id: orderRes.body.order.id } });
    expect(order.status).toBe("PENDING_PAYMENT");
    const stocked = await prisma.product.findUniqueOrThrow({ where: { id: product.id } });
    expect(stocked.stockQty).toBe(10);
  });

  it("blocks initiating payment for someone else's order", async () => {
    const { token } = await createUser();
    const { token: otherToken, user: other } = await createUser();
    const { product } = await createCatalog();

    const orderRes = await request(app)
      .post("/api/orders")
      .set("Authorization", `Bearer ${token}`)
      .send({ items: [{ productId: product.id, quantity: 1 }] });

    const payRes = await request(app)
      .post("/api/payments/initiate")
      .set("Authorization", `Bearer ${otherToken}`)
      .send({ type: "order", refId: orderRes.body.order.id, momoNumber: other.phone });

    expect(payRes.status).toBe(404);
  });
});
