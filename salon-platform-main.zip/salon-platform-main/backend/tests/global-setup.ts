import { execSync } from "node:child_process";

export default function setup() {
  // Non-destructive: applies committed migrations to the throwaway test DB.
  execSync("npx prisma migrate deploy", {
    cwd: __dirname + "/..",
    env: {
      ...process.env,
      DATABASE_URL: "postgresql://salon:salon@localhost:5434/salon_test",
    },
    stdio: "inherit",
  });
}
