/**
 * Seeds a demo dataset: the admin (salon owner) account, service
 * categories with daily caps, services, and retail products.
 *
 * Catalog contents are placeholders pending the client's real list
 * (Requirements Doc §7 open questions) — safe to edit freely.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminPhone = process.env.ADMIN_PHONE ?? "233240000000";
  const adminPassword = process.env.ADMIN_PASSWORD ?? "ChangeMe!123";
  const adminName = process.env.ADMIN_NAME ?? "Salon Owner";

  await prisma.user.upsert({
    where: { phone: adminPhone },
    update: { role: "ADMIN" },
    create: {
      name: adminName,
      phone: adminPhone,
      passwordHash: await bcrypt.hash(adminPassword, 10),
      role: "ADMIN",
    },
  });

  const categories = [
    { name: "Tiny Braids", dailyCap: 3 },
    { name: "Medium Braids", dailyCap: 5 },
    { name: "Large Braids", dailyCap: 8 },
    { name: "Natural Hair Care", dailyCap: 6 },
    { name: "Styling & Finishing", dailyCap: 10 },
  ];
  const categoryIds = new Map<string, string>();
  for (const c of categories) {
    const row = await prisma.serviceCategory.upsert({
      where: { name: c.name },
      update: { dailyCap: c.dailyCap },
      create: c,
    });
    categoryIds.set(c.name, row.id);
  }

  // Prices in pesewas (GHS minor units)
  const services = [
    {
      name: "Knotless Tiny Braids",
      category: "Tiny Braids",
      priceMin: 35000,
      priceMax: 60000,
      description:
        "Ultra-neat tiny knotless braids, waist length available. A full-day style — booked with a strict daily limit so every client gets full attention.",
    },
    {
      name: "Micro Twists",
      category: "Tiny Braids",
      priceMin: 30000,
      priceMax: 50000,
      description: "Delicate micro twists with a natural finish.",
    },
    {
      name: "Medium Knotless Braids",
      category: "Medium Braids",
      priceMin: 20000,
      priceMax: 35000,
      description: "The classic everyday protective style, shoulder to mid-back length.",
    },
    {
      name: "Jumbo Box Braids",
      category: "Large Braids",
      priceMin: 12000,
      priceMax: 20000,
      description: "Bold jumbo braids, done in a single sitting.",
    },
    {
      name: "Silk Press & Trim",
      category: "Natural Hair Care",
      priceMin: 10000,
      priceMax: 18000,
      description: "Deep condition, silk press, and a healthy-hair trim.",
    },
    {
      name: "Wash, Treat & Style",
      category: "Natural Hair Care",
      priceMin: 8000,
      priceMax: 15000,
      description: "Cleansing wash, steam treatment, and a finished style.",
    },
    {
      name: "Bridal / Event Styling",
      category: "Styling & Finishing",
      priceMin: 25000,
      priceMax: 60000,
      description: "Occasion styling with trial session available.",
    },
  ];
  for (const s of services) {
    const categoryId = categoryIds.get(s.category)!;
    const existing = await prisma.service.findFirst({ where: { name: s.name } });
    if (!existing) {
      await prisma.service.create({
        data: {
          name: s.name,
          description: s.description,
          priceMin: s.priceMin,
          priceMax: s.priceMax,
          categoryId,
        },
      });
    }
  }

  const products = [
    {
      name: "Shea Butter Leave-In Conditioner 250ml",
      price: 6500,
      stockQty: 24,
      description: "Rich daily leave-in for braids and natural hair.",
    },
    {
      name: "Braid Sheen Spray 200ml",
      price: 4500,
      stockQty: 30,
      description: "Light sheen and itch relief for protective styles.",
    },
    {
      name: "Peppermint Scalp Oil 100ml",
      price: 5500,
      stockQty: 18,
      description: "Cooling scalp oil blend for growth and comfort.",
    },
    {
      name: "Satin Bonnet (Large)",
      price: 3500,
      stockQty: 40,
      description: "Extra-large satin bonnet that protects styles overnight.",
    },
    {
      name: "Edge Control Gel 60ml",
      price: 3000,
      stockQty: 0,
      description: "Strong-hold edge control, flake free.",
    },
  ];
  for (const p of products) {
    const existing = await prisma.product.findFirst({ where: { name: p.name } });
    if (!existing) {
      await prisma.product.create({ data: p });
    }
  }

  console.log("Seed complete. Admin login:", adminPhone);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
