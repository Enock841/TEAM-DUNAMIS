import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    globalSetup: "./tests/global-setup.ts",
    fileParallelism: false, // tests share one database
    testTimeout: 20_000,
    hookTimeout: 30_000,
    env: {
      NODE_ENV: "test",
      DATABASE_URL: "postgresql://salon:salon@localhost:5434/salon_test",
      JWT_SECRET: "test-secret-not-for-production",
      PAYMENT_PROVIDER: "mock",
      BOOKING_MIN_ADVANCE_DAYS: "2",
    },
  },
});
