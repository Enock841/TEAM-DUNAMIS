# API Reference

Base URL: `/api` · All responses JSON · Errors: `{ "error": { "code", "message", "details?" } }`
Auth: `Authorization: Bearer <JWT>` · **(admin)** requires `role=ADMIN`.
Money values are integers in pesewas (GHS minor units).

## Auth

| Method | Endpoint | Body | Response |
| --- | --- | --- | --- |
| POST | `/auth/register` | `{ name, phone, email?, password }` | `201 { user, token }` — 409 on duplicate phone/email |
| POST | `/auth/login` | `{ identifier, password }` (phone or email) | `{ user, token }` |
| GET | `/auth/me` | — (auth) | `{ user }` |

## Categories

| Method | Endpoint | Body / Query | Response |
| --- | --- | --- | --- |
| GET | `/categories` | — | `[{ id, name, dailyCap }]` |
| POST | `/categories` | `{ name, dailyCap }` (admin) | `201 { category }` |
| PUT | `/categories/:id` | `{ name?, dailyCap? }` (admin) | `{ category }` |
| DELETE | `/categories/:id` | (admin) | `204` — 409 if it still has services |

## Services

| Method | Endpoint | Body / Query | Response |
| --- | --- | --- | --- |
| GET | `/services` | `?categoryId=` | active services with category |
| GET | `/services/all` | (admin) | includes hidden services |
| GET | `/services/:id` | — | one service |
| POST | `/services` | `{ name, description, categoryId, priceMin, priceMax, imageUrl?, active? }` (admin) | `201 { service }` |
| PUT | `/services/:id` | partial fields (admin) | `{ service }` |
| DELETE | `/services/:id` | (admin) | `204` (soft delete) |

## Bookings

| Method | Endpoint | Body / Query | Response |
| --- | --- | --- | --- |
| GET | `/bookings/availability` | `?serviceId=&date=YYYY-MM-DD` | `{ date, dailyCap, slotsRemaining, available, minAdvanceDays, timeSlots[] }` |
| POST | `/bookings` | `{ serviceId, date, timeSlot, notes? }` (auth) | `201 { booking, payment: { amountMinor } }` — 400 `TOO_SOON`, 409 `DAILY_CAP_REACHED` / `SLOT_TAKEN` |
| GET | `/bookings/me` | (auth) | caller's bookings |
| GET | `/bookings` | `?date=&categoryId=&status=` (admin) | bookings with customer details |
| PUT | `/bookings/:id/status` | `{ status: CONFIRMED\|COMPLETED\|CANCELLED\|NO_SHOW }` (admin) | `{ booking }` (audited) |

## Products

| Method | Endpoint | Body / Query | Response |
| --- | --- | --- | --- |
| GET | `/products` | — | active products with `inStock` |
| GET | `/products/all` | (admin) | includes hidden products |
| GET | `/products/:id` | — | one product |
| POST | `/products` | `{ name, description, price, stockQty, imageUrl?, active? }` (admin) | `201 { product }` |
| PUT | `/products/:id` | partial fields (admin) | `{ product }` |
| PUT | `/products/:id/stock` | `{ stockQty, reason? }` (admin) | `{ product }` (audited) |
| DELETE | `/products/:id` | (admin) | `204` (soft delete) |

## Orders

| Method | Endpoint | Body / Query | Response |
| --- | --- | --- | --- |
| POST | `/orders` | `{ items: [{ productId, quantity }] }` (auth) | `201 { order, payment }` — 409 `INSUFFICIENT_STOCK` |
| GET | `/orders/me` | (auth) | caller's orders with items |
| GET | `/orders` | `?status=` (admin) | all orders with customer |
| PUT | `/orders/:id/status` | `{ status: FULFILLED\|CANCELLED }` (admin) | `{ order }` |

## Payments

| Method | Endpoint | Body / Query | Response |
| --- | --- | --- | --- |
| POST | `/payments/initiate` | `{ type: booking\|order, refId, momoNumber }` (auth, must own the ref) | `201 { reference, status, amountMinor }` |
| POST | `/payments/webhook` | provider payload (HMAC-verified) | `{ received: true }` |
| POST | `/payments/mock/settle` | `{ reference, outcome }` (dev/mock only) | `{ ok: true }` |
| GET | `/payments` | (admin) | payment log with linked booking/order |
| GET | `/payments/:reference` | (auth, owner or admin) | `{ reference, status, amountMinor, type, refId, refStatus }` |

## Admin

| Method | Endpoint | Query | Response |
| --- | --- | --- | --- |
| GET | `/admin/stats` | — | dashboard counters + revenue |
| GET | `/admin/customers` | `?search=` | customers with booking/order counts |
| GET | `/admin/customers/:id` | — | full profile with history |
| GET | `/admin/audit-logs` | — | latest 200 audit entries |

## Misc

| Method | Endpoint | Response |
| --- | --- | --- |
| GET | `/health` | `{ status: "ok", uptime }` |

Rate limits: 300 requests / 15 min per IP (all `/api`), 20 / 15 min on register/login.
