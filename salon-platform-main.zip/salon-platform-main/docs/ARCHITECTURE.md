# Architecture

This document extends the Week 3 Architecture document (ADR-001 … ADR-005, all honored)
with the concrete design of the implemented system.

## System overview

```
┌─────────────┐   HTTPS/JSON    ┌──────────────┐    SQL     ┌────────────┐
│  Next.js 16 │ ──────────────► │  Express 5   │ ─────────► │ PostgreSQL │
│  (Vercel)   │  Authorization: │  REST API    │  (Prisma)  │ (Railway)  │
│  customer + │  Bearer <JWT>   │  (Railway)   │            └────────────┘
│  admin UI   │                 │              │──► Paystack (MoMo charge + webhook)
└─────────────┘                 └──────────────┘
```

- **One Next.js app** serves both the customer site and `/admin` (ADR-001). Public pages
  (home, services, products) are **server-rendered with 60s revalidation** for SEO and
  fast first paint on 3G (US-13, NFR-01); interactive flows are client components.
- **Express API** is stateless: any instance can serve any request; horizontal scaling is
  safe because booking-cap enforcement locks at the database level (see below).
- **Auth** (ADR-004): bcrypt-hashed passwords; JWT carrying `{sub, role, name}` with a
  24h expiry, sent as an `Authorization: Bearer` header. `requireAuth` / `requireAdmin`
  middleware enforce RBAC. Login failures never reveal which credential was wrong (US-02).

## Key mechanisms

### Booking daily cap (US-05/US-06) — the core business rule
`createBooking` runs in one transaction that:
1. `SELECT … FOR UPDATE` on the service's **category row** — serializes all bookings for
   that category across every API instance;
2. expires stale unpaid bookings (30 min TTL, configurable) so abandoned checkouts don't
   block real customers;
3. counts non-cancelled bookings for (category, date) and rejects with `409
   DAILY_CAP_REACHED` when the cap is met;
4. rejects a duplicate (service, date, timeSlot) with `409 SLOT_TAKEN`;
5. creates the booking as `PENDING_PAYMENT`.

A test fires two concurrent requests at the last remaining slot and asserts exactly one
succeeds.

### Payments (US-09/US-10)
`PaymentProvider` interface with two implementations selected by `PAYMENT_PROVIDER`:
- **mock** — dev/demo; outcome controlled by `MOCK_PAYMENT_OUTCOME` (default success) so
  the end-to-end flow works offline.
- **paystack** — real MoMo charge; webhook verified with timing-safe HMAC-SHA512.

Amounts are always read from the server-side entity, never from the client. Settlement to
the owner's MoMo number is configured at the gateway (Paystack settlement account) —
the platform never holds funds and never stores wallet credentials (NFR-03).

`settlePayment` is **idempotent** (a settled payment is never re-processed) and, on
success, atomically: confirms the booking, or marks the order `PAID` and decrements stock
with an oversell guard (`UPDATE … WHERE stock_qty >= qty`); a paid-but-out-of-stock order
is cancelled and flagged `ORDER_REFUND_REQUIRED` in the audit log.

### Inventory (US-07/US-08)
Stock is validated at order creation but only **deducted after successful payment**, per
US-08 AC1. Every deduction and manual adjustment writes an `AuditLog` row (NFR-07).

### Money
All amounts are **integers in pesewas** (GHS minor units) end-to-end — no floating-point
rounding anywhere.

## Security checklist

- Passwords: bcrypt (cost 10). JWTs signed with `JWT_SECRET`, 24h expiry.
- Validation: every request body/query parsed with Zod; unknown routes 404; consistent
  `{ error: { code, message } }` shape; Prisma P2002 mapped to 409.
- `helmet` security headers; CORS restricted to `CORS_ORIGIN` allowlist; rate limiting
  (300 req/15min general, 20/15min on credential endpoints); 1 MB JSON body limit.
- Ownership checks: customers can only see/pay for their own bookings/orders; customer
  list and audit log are admin-only (NFR-06).
- Payment webhook: raw-body HMAC verification; mock settle endpoint disabled in prod.
- Secrets only via environment variables; `.env` git-ignored; `.env.example` documents
  every variable.

## Documented assumptions (open questions resolved)

| Open question (Requirements §7) | Decision taken | Where |
| --- | --- | --- |
| 2-day advance minimum: platform-wide or per category? | Platform-wide, configurable via `BOOKING_MIN_ADVANCE_DAYS` (default 2) | backend env |
| Guest booking allowed? | Account required to book/purchase (keeps history per US-01/12); browsing needs no account | design |
| SMS/WhatsApp confirmation required? | On-screen + account history for MVP; SMS deferred (out of MVP scope) | plan |
| Which MoMo provider? | Paystack (PCI-compliant, supports MTN/Vodafone/AirtelTigo in GHS) behind a provider interface so it can be swapped | payments module |
| Multiple staff logins? | Single ADMIN role for MVP; schema's `Role` enum extends cleanly | schema |
| Catalog contents | Seeded placeholder catalog, fully editable from the dashboard | seed |
| Booking payment amount | Customer pays the service's **minimum price** online to confirm; balance settled in person (price is a range) | bookings module |
| Salon name/branding | "Beryl’s Beauty Mark" (client-confirmed 2026-07-23; was "Bloom & Braids" placeholder) | frontend |

## Non-functional requirements → implementation

- **NFR-01 (3G performance):** SSR + static generation, system-font fallbacks, no heavy
  client libraries; first-load JS kept minimal.
- **NFR-02 (soft pink, simple):** pastel token-based theme, light + dark.
- **NFR-04 (availability):** stateless API behind managed platforms; `/api/health` for
  platform health checks; zero-downtime deploys on Vercel/Railway.
- **NFR-05 (responsive):** mobile-first Tailwind layout; hamburger nav on mobile,
  full nav on desktop; tested at common breakpoints.
- **NFR-07 (auditability):** `audit_logs` table; admin viewer at `/admin` → API
  `GET /api/admin/audit-logs`.
