# Database

PostgreSQL 16, managed by Prisma migrations (`backend/prisma/`). 9 tables: the 8 ERD
entities from the Week 3 document plus `audit_logs` (NFR-07).

## Entity-relationship overview

```
users 1───* bookings *───1 services *───1 service_categories (dailyCap)
users 1───* orders 1───* order_items *───1 products (stock_qty)
payments *───1 bookings (optional)          audit_logs *───1 users (optional actor)
payments *───1 orders   (optional)
```

## Tables

| Table | Purpose | Notable columns / rules |
| --- | --- | --- |
| `users` | Customers + admin | `phone` unique (US-01 duplicate prevention), `email` unique-nullable, `passwordHash` (bcrypt), `role` enum, soft delete |
| `service_categories` | Booking-cap grouping | `name` unique, `dailyCap` (default 3), soft delete |
| `services` | Bookable services | `priceMin`/`priceMax` in pesewas, `active` flag, FK → category (`Restrict`), soft delete |
| `bookings` | Appointments | `date` (DATE), `timeSlot`, status enum (`PENDING_PAYMENT → CONFIRMED → COMPLETED`, or `CANCELLED`/`NO_SHOW`), indexes on `(serviceId, date)` and `date` for cap counting |
| `products` | Retail items | `price`, `stockQty` (never negative — guarded update), `active`, soft delete |
| `orders` | Purchases | `totalMinor` captured at checkout, status enum |
| `order_items` | Order ↔ product join | `quantity`, `unitPriceMinor` captured at purchase time (price changes don't rewrite history) |
| `payments` | Charge records | unique `reference`, links to booking **or** order (`SetNull`), provider + providerRef, status enum |
| `audit_logs` | NFR-07 trail | `actorId` (null = system), `action`, `entityType/Id`, JSON `detail`, indexed by entity and time |

## Integrity strategy

- **Foreign keys**: `Restrict` on user/service/product references (history is never
  orphaned), `Cascade` order → items, `SetNull` payment → booking/order.
- **Soft deletes** (`deletedAt`) on catalog entities so past bookings/orders keep their
  references; customer-facing queries always filter `deletedAt: null, active: true`.
- **Concurrency**: booking caps enforced under `SELECT … FOR UPDATE` on the category row;
  stock decrements use conditional `UPDATE … WHERE stock_qty >= qty`.
- **Money**: integers (pesewas) everywhere.

## Operations

```bash
npm run migrate       # apply committed migrations (deploy)
npm run migrate:dev   # create a new migration from schema changes (dev)
npm run seed          # idempotent demo catalog + admin account
```

Backups: Railway provides automated daily Postgres backups; before risky migrations run
`pg_dump "$DATABASE_URL" > backup.sql`.
