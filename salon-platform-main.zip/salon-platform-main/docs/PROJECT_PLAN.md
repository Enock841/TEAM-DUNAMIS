# Project Plan & Progress

## Requirements analysis summary

**Functional requirements:** US-01 … US-13 (Requirements Doc §4) — all implemented.
**Non-functional:** NFR-01 … NFR-07 — all addressed (see ARCHITECTURE.md mapping).

**Gaps/ambiguities found in the source docs and how they were resolved:**
- Open questions (§7) resolved with documented defaults — see the assumptions table in
  ARCHITECTURE.md. All are configurable or isolated so a different client answer is a
  small change, not a rewrite.
- The Week 3 API schema omitted order/booking status transitions, customer search, and
  audit access; these were added as `PUT /orders/:id/status`, admin customer endpoints,
  and `GET /admin/audit-logs` (needed for US-11/US-12/NFR-07 acceptance criteria).
- Contradiction check: US-04 AC2 (2-day minimum) marked "pending confirmation" — kept,
  env-configurable, surfaced to users in the booking UI.
- Risk: double-booking under concurrency — mitigated with DB row locking + a regression
  test; this was treated as the highest-risk requirement (it is the client's core pain).
- Risk: overselling stock when payment succeeds after stock ran out — mitigated with
  guarded decrements and an explicit `ORDER_REFUND_REQUIRED` audit flag.

## Phases & status

| Phase | Scope | Status |
| --- | --- | --- |
| 1. Analysis & architecture | Docs review, ADR adoption, assumption log | ✅ done |
| 2. Database | Prisma schema (9 tables), migration, seed | ✅ done |
| 3. Backend core | Auth/JWT/RBAC, categories, services (Sprint 1) | ✅ done |
| 4. Booking engine | Availability, cap enforcement, pending-TTL (Sprint 1) | ✅ done |
| 5. Shop | Products, cart-side validation, orders (Sprint 2) | ✅ done |
| 6. Payments | Provider abstraction, mock + Paystack, webhook, settlement (Sprint 2) | ✅ done |
| 7. Admin API | Stats, customers, audit log (Sprint 1–2) | ✅ done |
| 8. Frontend public | Home, services, booking flow, shop, cart, checkout | ✅ done |
| 9. Frontend accounts | Register/login, history | ✅ done |
| 10. Admin dashboard | 8 sections (overview…payments) | ✅ done |
| 11. Testing | 24 backend tests incl. concurrency race; lint+types clean both apps | ✅ done |
| 12. Docs | README, architecture, API, database, deployment, this plan | ✅ done |
| 13. DevOps | Docker, compose, GitHub Actions CI, health checks | ✅ done |
| 14. Deployment | Vercel + Railway (needs the team's accounts) | ⬜ pending accounts |

## Verification record (last full run)

- Backend: `npm test` → 24/24 passing · `lint` clean · `tsc --noEmit` clean.
- Frontend: `next build` succeeds (20 routes) · `lint` clean · `tsc --noEmit` clean.
- Manual E2E against live dev servers: register → availability → book → mock-pay →
  booking `CONFIRMED`; order → pay → stock 30→28, order `PAID`; admin stats + audit
  trail populated; SSR services page renders the catalog with prices.

## Known issues / technical debt

1. **Real Paystack flow untested against the live sandbox** — the adapter follows the
   documented charge/webhook API but needs a test-key smoke run before production.
2. **JWT in localStorage** — acceptable for MVP with the strict CSP-adjacent measures in
   place; migrating to httpOnly refresh-token cookies is the planned hardening step.
3. **Service update validation** — a partial update changing only `priceMin` isn't
   cross-checked against the stored `priceMax` (create and combined updates are).
4. **No pagination on admin lists** (capped at 100–200 rows) — fine at salon scale;
   add cursor pagination if the business grows.
5. **Images are URL-based** — Supabase Storage upload UI is a Phase-2 nicety; the admin
   pastes an image URL for now.
6. **SMS/WhatsApp notifications** deferred per open question; on-screen + history only.

## Future improvements

- Refunds workflow surfaced in the dashboard (currently audit-flag + manual).
- Per-service durations and true time-grid scheduling (beyond per-category caps).
- Customer reviews/photos per service; loyalty features (explicitly out of MVP scope).
