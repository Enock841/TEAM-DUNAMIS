# Deployment

Environments: **development** (local, mock payments) → **staging** (Railway/Vercel
preview, Paystack test keys) → **production** (Paystack live keys). Test runs in CI.

## Backend + database — Railway

1. Create a Railway project → add **PostgreSQL** (copy its `DATABASE_URL`).
2. Add a service from this GitHub repo, root directory `backend/`. Railway detects the
   `Dockerfile`; the container runs `prisma migrate deploy` before starting, so schema
   updates ship automatically with each deploy (zero-downtime rolling restart).
3. Set environment variables:

   | Variable | Value |
   | --- | --- |
   | `DATABASE_URL` | from the Railway Postgres plugin |
   | `JWT_SECRET` | `openssl rand -hex 32` — **never reuse the dev value** |
   | `NODE_ENV` | `production` |
   | `CORS_ORIGIN` | `https://<your-app>.vercel.app` (comma-separate extras) |
   | `PAYMENT_PROVIDER` | `paystack` (or `mock` for staging demos) |
   | `PAYSTACK_SECRET_KEY` | from the Paystack dashboard |
   | `BOOKING_MIN_ADVANCE_DAYS` | `2` (adjust after client confirmation) |

4. Seed once from your machine:
   `cd backend && DATABASE_URL=<railway-url> ADMIN_PHONE=<owner> ADMIN_PASSWORD=<strong> npm run seed`
5. In the Paystack dashboard: set the webhook URL to
   `https://<railway-app>/api/payments/webhook` and configure the **settlement account**
   to the owner's MoMo number (US-10).

## Frontend — Vercel

1. Import the repo in Vercel, set **Root Directory** to `frontend/` (framework:
   Next.js — zero config).
2. Environment variables:

   | Variable | Value |
   | --- | --- |
   | `NEXT_PUBLIC_API_URL` | `https://<railway-app>/api` |
   | `NEXT_PUBLIC_SITE_URL` | `https://<your-app>.vercel.app` |

3. Every push to `main` auto-deploys; PRs get preview URLs (use them as staging).

## Health & monitoring

- API health: `GET /api/health` — wire this into Railway's health check and an uptime
  monitor (e.g. UptimeRobot free tier) for the NFR-04 99% target.
- Logs: structured JSON (pino) in Railway's log viewer; Vercel captures frontend logs.

## Rollback

- **Vercel:** Deployments → previous build → *Promote to Production* (instant).
- **Railway:** Deployments → redeploy the previous image (instant).
- **Database:** migrations are additive by convention; to restore data use the latest
  Railway backup or your `pg_dump` snapshot. Avoid destructive column drops in the same
  release as code that still reads them.

## Local production rehearsal

```bash
docker compose --profile full up --build   # API on :4000 against containerized Postgres
```
