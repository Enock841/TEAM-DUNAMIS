/**
 * Shared TypeScript models mirroring the backend API response shapes.
 * All *Minor / price fields are integers in pesewas (GHS minor units) —
 * format with lib/money.ts before display.
 */
export interface User {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  role: "CUSTOMER" | "ADMIN";
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  dailyCap: number;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  priceMin: number;
  priceMax: number;
  imageUrl: string | null;
  active: boolean;
  category: Category;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stockQty: number;
  inStock: boolean;
  imageUrl: string | null;
  active: boolean;
}

export type BookingStatus =
  | "PENDING_PAYMENT"
  | "CONFIRMED"
  | "COMPLETED"
  | "CANCELLED"
  | "NO_SHOW";

export interface Booking {
  id: string;
  date: string;
  timeSlot: string;
  status: BookingStatus;
  notes?: string | null;
  createdAt: string;
  service: {
    id: string;
    name: string;
    priceMin: number;
    priceMax: number;
    category?: { id: string; name: string };
  };
  user?: { id: string; name: string; phone: string; email: string | null };
}

export type OrderStatus = "PENDING_PAYMENT" | "PAID" | "FULFILLED" | "CANCELLED";

export interface OrderItem {
  id: string;
  quantity: number;
  unitPriceMinor: number;
  product: { id: string; name: string; imageUrl: string | null };
}

export interface Order {
  id: string;
  status: OrderStatus;
  totalMinor: number;
  createdAt: string;
  items: OrderItem[];
  user?: { id: string; name: string; phone: string; email: string | null };
}

export interface Availability {
  date: string;
  dailyCap: number;
  slotsRemaining: number;
  available: boolean;
  minAdvanceDays: number;
  timeSlots: { slot: string; available: boolean }[];
}

export type PaymentStatus = "PENDING" | "SUCCESS" | "FAILED";

export interface Payment {
  id: string;
  reference: string;
  type: "BOOKING" | "ORDER";
  amountMinor: number;
  currency: string;
  status: PaymentStatus;
  provider: string;
  momoNumber: string | null;
  createdAt: string;
  booking?: { id: string; date: string; service: { name: string } } | null;
  order?: { id: string; totalMinor: number } | null;
}

export interface AdminStats {
  bookingsToday: number;
  upcomingBookings: number;
  ordersAwaitingFulfilment: number;
  lowStockProducts: number;
  totalCustomers: number;
  totalRevenueMinor: number;
}

export interface CustomerSummary {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  createdAt: string;
  _count: { bookings: number; orders: number };
}
