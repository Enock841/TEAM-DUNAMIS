"use client";

/**
 * Shopping cart state (US-07), persisted to localStorage so the cart
 * survives reloads. Quantities are clamped to the product's known stock;
 * the backend re-validates stock at checkout regardless, so this is a UX
 * nicety, not a security boundary.
 */
import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Product } from "./types";

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartState {
  items: CartItem[];
  count: number;
  totalMinor: number;
  add: (product: Product, quantity?: number) => void;
  setQuantity: (productId: string, quantity: number) => void;
  remove: (productId: string) => void;
  clear: () => void;
}

const CartContext = createContext<CartState | null>(null);
const STORAGE_KEY = "salon_cart";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    // Deferred so hydration completes before client-only cart state lands
    queueMicrotask(() => {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (raw) setItems(JSON.parse(raw) as CartItem[]);
      } catch {
        // corrupted cart — start fresh
      }
      setHydrated(true);
    });
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items, hydrated]);

  const value = useMemo<CartState>(() => {
    const clamp = (product: Product, qty: number) =>
      Math.max(1, Math.min(qty, product.stockQty));
    return {
      items,
      count: items.reduce((n, i) => n + i.quantity, 0),
      totalMinor: items.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
      add: (product, quantity = 1) =>
        setItems((prev) => {
          const existing = prev.find((i) => i.product.id === product.id);
          if (existing) {
            return prev.map((i) =>
              i.product.id === product.id
                ? { ...i, product, quantity: clamp(product, i.quantity + quantity) }
                : i,
            );
          }
          return [...prev, { product, quantity: clamp(product, quantity) }];
        }),
      setQuantity: (productId, quantity) =>
        setItems((prev) =>
          quantity <= 0
            ? prev.filter((i) => i.product.id !== productId)
            : prev.map((i) =>
                i.product.id === productId
                  ? { ...i, quantity: clamp(i.product, quantity) }
                  : i,
              ),
        ),
      remove: (productId) => setItems((prev) => prev.filter((i) => i.product.id !== productId)),
      clear: () => setItems([]),
    };
  }, [items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartState {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
