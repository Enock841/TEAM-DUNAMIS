/** Prices are stored in pesewas (GHS minor units). */
export function formatGHS(minor: number): string {
  return `GH₵ ${(minor / 100).toLocaleString("en-GH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatRange(minMinor: number, maxMinor: number): string {
  if (minMinor === maxMinor) return formatGHS(minMinor);
  return `${formatGHS(minMinor)} – ${formatGHS(maxMinor)}`;
}
