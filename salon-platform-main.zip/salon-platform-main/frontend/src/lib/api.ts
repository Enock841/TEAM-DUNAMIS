/**
 * Browser-side API client: a thin typed fetch wrapper that attaches the
 * stored JWT and normalizes backend errors into ApiClientError so UI
 * components can show the server's human-readable message directly.
 */
export const API_URL =
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000/api";

const TOKEN_KEY = "salon_token";

/** Read the stored session token (null on the server or when logged out). */
export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_KEY);
}

/** Persist the session token; pass null to log out. */
export function setToken(token: string | null): void {
  if (typeof window === "undefined") return;
  if (token) window.localStorage.setItem(TOKEN_KEY, token);
  else window.localStorage.removeItem(TOKEN_KEY);
}

/** Error raised for any non-2xx response, carrying status + backend error code. */
export class ApiClientError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly code?: string,
  ) {
    super(message);
  }
}

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
  /** Attach the stored JWT (default true). */
  auth?: boolean;
}

/**
 * Fire-and-forget refresh of the cached public pages (services/products)
 * after an admin changes the catalog, so visitors see it immediately.
 */
export function refreshPublicPages(): void {
  if (typeof window === "undefined") return;
  void fetch("/api/revalidate", { method: "POST" }).catch(() => {});
}

/** Upload an image (admin) and return its permanent URL for imageUrl fields. */
export async function apiUploadImage(file: File): Promise<string> {
  const form = new FormData();
  form.append("image", file);
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;

  let response: Response;
  try {
    response = await fetch(`${API_URL}/uploads`, { method: "POST", headers, body: form });
  } catch {
    throw new ApiClientError(0, "Could not reach the server. Check your connection.");
  }
  const data = (await response.json().catch(() => ({}))) as {
    url?: string;
    error?: { message?: string; code?: string };
  };
  if (!response.ok || !data.url) {
    throw new ApiClientError(
      response.status,
      data.error?.message ?? "Upload failed",
      data.error?.code,
    );
  }
  return data.url;
}

/** Perform a JSON request against the backend, e.g. api<Service[]>("/services"). */
export async function api<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = "GET", body, auth = true } = options;
  const headers: Record<string, string> = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const token = auth ? getToken() : null;
  if (token) headers["Authorization"] = `Bearer ${token}`;

  let response: Response;
  try {
    response = await fetch(`${API_URL}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiClientError(0, "Could not reach the server. Check your connection.");
  }

  if (response.status === 204) return undefined as T;

  const data = (await response.json().catch(() => ({}))) as {
    error?: { message?: string; code?: string };
  };

  if (!response.ok) {
    throw new ApiClientError(
      response.status,
      data.error?.message ?? "Something went wrong",
      data.error?.code,
    );
  }
  return data as T;
}
