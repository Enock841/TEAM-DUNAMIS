import { API_URL } from "./api";

/**
 * Server-side fetch for public endpoints (services, products) so these
 * pages are server-rendered and indexable (US-13). Responses revalidate
 * every 60s; failures return null so pages degrade gracefully instead
 * of crashing the build when the API is unreachable.
 */
export async function serverGet<T>(path: string): Promise<T | null> {
  try {
    const res = await fetch(`${API_URL}${path}`, { next: { revalidate: 60 } });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}
