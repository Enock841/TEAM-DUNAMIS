"use client";

/**
 * Global authentication state. On first mount it restores a stored
 * session by validating the saved token against /auth/me; `loading`
 * stays true until that check finishes so guards (account page, admin
 * layout) don't redirect prematurely.
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { api, getToken, setToken } from "./api";
import type { User } from "./types";

interface AuthState {
  user: User | null;
  /** True until the stored session (if any) has been checked. */
  loading: boolean;
  login: (identifier: string, password: string) => Promise<User>;
  register: (input: {
    name: string;
    phone: string;
    email?: string;
    password: string;
  }) => Promise<User>;
  updateProfile: (input: {
    name?: string;
    phone?: string;
    email?: string | null;
  }) => Promise<User>;
  logout: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = getToken()
      ? api<{ user: User }>("/auth/me")
          .then((res) => setUser(res.user))
          .catch(() => setToken(null))
      : Promise.resolve();
    void session.finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (identifier: string, password: string) => {
    const res = await api<{ user: User; token: string }>("/auth/login", {
      method: "POST",
      body: { identifier, password },
      auth: false,
    });
    setToken(res.token);
    setUser(res.user);
    return res.user;
  }, []);

  const register = useCallback(
    async (input: { name: string; phone: string; email?: string; password: string }) => {
      const res = await api<{ user: User; token: string }>("/auth/register", {
        method: "POST",
        body: input,
        auth: false,
      });
      setToken(res.token);
      setUser(res.user);
      return res.user;
    },
    [],
  );

  const updateProfile = useCallback(
    async (input: { name?: string; phone?: string; email?: string | null }) => {
      const res = await api<{ user: User }>("/auth/me", { method: "PUT", body: input });
      setUser(res.user);
      return res.user;
    },
    [],
  );

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, register, updateProfile, logout }),
    [user, loading, login, register, updateProfile, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
