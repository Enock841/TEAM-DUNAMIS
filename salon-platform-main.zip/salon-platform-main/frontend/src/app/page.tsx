/**
 * Home page — static, server-rendered marketing page (fast on 3G per
 * NFR-01, indexable per US-13): hero, value highlights, and the
 * four-step "how booking works" strip from the pitch deck.
 */
import Link from "next/link";

const highlights = [
  {
    title: "Book online, skip the calls",
    body: "See real availability and lock in your slot in under a minute — no phone tag.",
    icon: "📅",
  },
  {
    title: "Never double-booked",
    body: "Our schedule caps each style category per day, so your stylist's time is truly yours.",
    icon: "✨",
  },
  {
    title: "Pay with Mobile Money",
    body: "Confirm your booking or checkout instantly with MoMo. A receipt follows right away.",
    icon: "📱",
  },
];

export default function HomePage() {
  return (
    <div>
      {/* Hero */}
      <section className="bg-surface-2">
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-4 py-20 sm:py-28">
          <span className="rounded-full bg-primary-soft px-4 py-1.5 text-xs font-semibold tracking-wide text-primary-strong uppercase">
            Kumasi · Braids &amp; natural hair
          </span>
          <h1 className="max-w-2xl font-display text-4xl leading-tight font-semibold sm:text-5xl">
            Beautiful hair, booked on <span className="text-primary">your</span> schedule.
          </h1>
          <p className="max-w-xl text-lg text-muted">
            Browse our styles, pick a date that works, and pay with Mobile Money. Your slot is
            reserved — no calls, no queues, no surprises.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              href="/services"
              className="rounded-full bg-primary px-7 py-3 font-medium text-white transition-colors hover:bg-primary-strong"
            >
              Book a service
            </Link>
            <Link
              href="/products"
              className="rounded-full border border-line bg-surface px-7 py-3 font-medium text-ink transition-colors hover:border-primary"
            >
              Shop products
            </Link>
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-6 sm:grid-cols-3">
          {highlights.map((h) => (
            <div key={h.title} className="rounded-2xl border border-line bg-surface p-6">
              <span className="text-3xl" aria-hidden>
                {h.icon}
              </span>
              <h2 className="mt-4 font-display text-lg font-semibold">{h.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{h.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-6xl px-4 pb-20">
        <h2 className="font-display text-2xl font-semibold">How booking works</h2>
        <ol className="mt-6 grid gap-4 sm:grid-cols-4">
          {["Browse services", "Pick date & slot", "Pay by Mobile Money", "Get confirmation"].map(
            (step, i) => (
              <li key={step} className="rounded-2xl bg-surface-2 p-5">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-sm font-bold text-white">
                  {i + 1}
                </span>
                <p className="mt-3 font-medium">{step}</p>
              </li>
            ),
          )}
        </ol>
      </section>
    </div>
  );
}
