"use client";

/**
 * Admin service management (US-11 AC2): create/edit services, set the
 * price range, assign a category, and hide/show them on the public site.
 * Prices are entered in GH₵ and converted to pesewas for the API.
 */
import { useEffect, useState } from "react";
import { api, ApiClientError, refreshPublicPages } from "@/lib/api";
import type { Category, Service } from "@/lib/types";
import { formatRange } from "@/lib/money";
import { Badge, Button, Card, ErrorNote, Input, PageSpinner } from "@/components/ui";
import { ImageField } from "@/components/image-field";

interface ServiceForm {
  id?: string;
  name: string;
  description: string;
  categoryId: string;
  priceMinGhs: string;
  priceMaxGhs: string;
  imageUrl: string;
  active: boolean;
}

const emptyForm = (categoryId = ""): ServiceForm => ({
  name: "",
  description: "",
  categoryId,
  priceMinGhs: "",
  priceMaxGhs: "",
  imageUrl: "",
  active: true,
});

export default function AdminServicesPage() {
  const [services, setServices] = useState<Service[] | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [form, setForm] = useState<ServiceForm | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () =>
    Promise.all([
      api<Service[]>("/services/all"),
      api<Category[]>("/categories", { auth: false }),
    ])
      .then(([servicesRes, categoriesRes]) => {
        setServices(servicesRes);
        setCategories(categoriesRes);
      })
      .catch(() => setError("Could not load services"));

  useEffect(() => {
    void load();
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setBusy(true);
    setError(null);
    const body = {
      name: form.name,
      description: form.description,
      categoryId: form.categoryId,
      priceMin: Math.round(Number(form.priceMinGhs) * 100),
      priceMax: Math.round(Number(form.priceMaxGhs) * 100),
      imageUrl: form.imageUrl.trim() || null,
      active: form.active,
    };
    try {
      if (form.id) await api(`/services/${form.id}`, { method: "PUT", body });
      else await api("/services", { method: "POST", body });
      setForm(null);
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function toggleActive(service: Service) {
    setError(null);
    try {
      await api(`/services/${service.id}`, {
        method: "PUT",
        body: { active: !service.active },
      });
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Update failed");
    }
  }

  async function remove(service: Service) {
    if (!window.confirm(`Delete "${service.name}"? It will disappear from the site.`)) return;
    setError(null);
    try {
      await api(`/services/${service.id}`, { method: "DELETE" });
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Delete failed");
    }
  }

  function edit(service: Service) {
    setForm({
      id: service.id,
      name: service.name,
      description: service.description,
      categoryId: service.category.id,
      priceMinGhs: String(service.priceMin / 100),
      priceMaxGhs: String(service.priceMax / 100),
      imageUrl: service.imageUrl ?? "",
      active: service.active,
    });
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-semibold">Services</h1>
        <Button onClick={() => setForm(emptyForm(categories[0]?.id ?? ""))}>New service</Button>
      </div>

      {error && (
        <div className="mt-4">
          <ErrorNote message={error} />
        </div>
      )}

      {form && (
        <Card className="mt-6">
          <form onSubmit={save} className="grid gap-4 sm:grid-cols-2">
            <Input
              id="svc-name"
              label="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
              minLength={2}
            />
            <div className="flex flex-col gap-1.5">
              <label htmlFor="svc-cat" className="text-sm font-medium">
                Category
              </label>
              <select
                id="svc-cat"
                value={form.categoryId}
                onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
                className="rounded-xl border border-line bg-surface px-4 py-2.5 text-sm focus:border-primary focus:outline-none"
                required
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <Input
              id="svc-min"
              label="Price from (GH₵)"
              type="number"
              min={0}
              step="0.01"
              value={form.priceMinGhs}
              onChange={(e) => setForm({ ...form, priceMinGhs: e.target.value })}
              required
            />
            <Input
              id="svc-max"
              label="Price to (GH₵)"
              type="number"
              min={0}
              step="0.01"
              value={form.priceMaxGhs}
              onChange={(e) => setForm({ ...form, priceMaxGhs: e.target.value })}
              required
            />
            <div className="sm:col-span-2">
              <ImageField
                label="Photo (optional)"
                value={form.imageUrl}
                onChange={(imageUrl) => setForm({ ...form, imageUrl })}
              />
            </div>
            <div className="flex flex-col gap-1.5 sm:col-span-2">
              <label htmlFor="svc-desc" className="text-sm font-medium">
                Description
              </label>
              <textarea
                id="svc-desc"
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="rounded-xl border border-line bg-surface px-4 py-2.5 text-sm focus:border-primary focus:outline-none"
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(e) => setForm({ ...form, active: e.target.checked })}
              />
              Visible to customers
            </label>
            <div className="flex justify-end gap-2 sm:col-span-2">
              <Button type="button" variant="ghost" onClick={() => setForm(null)}>
                Cancel
              </Button>
              <Button type="submit" loading={busy}>
                {form.id ? "Save changes" : "Create service"}
              </Button>
            </div>
          </form>
        </Card>
      )}

      {services === null ? (
        <PageSpinner />
      ) : (
        <ul className="mt-6 space-y-3">
          {services.map((service) => (
            <li
              key={service.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-5"
            >
              <div>
                <p className="font-medium">
                  {service.name}
                  {!service.active && (
                    <span className="ml-2">
                      <Badge tone="neutral">Hidden</Badge>
                    </span>
                  )}
                </p>
                <p className="text-sm text-muted">
                  {service.category.name} · {formatRange(service.priceMin, service.priceMax)}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  className="px-4 py-2 text-xs"
                  onClick={() => edit(service)}
                >
                  Edit
                </Button>
                <Button
                  variant="ghost"
                  className="px-4 py-2 text-xs"
                  onClick={() => toggleActive(service)}
                >
                  {service.active ? "Hide" : "Show"}
                </Button>
                <Button
                  variant="danger"
                  className="px-4 py-2 text-xs"
                  onClick={() => remove(service)}
                >
                  Delete
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
