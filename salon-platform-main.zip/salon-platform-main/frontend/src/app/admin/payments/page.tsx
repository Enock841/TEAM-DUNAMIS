"use client";

/**
 * Admin payments log (US-10 AC2/AC3): every charge with its reference,
 * linked booking/order, MoMo number, and a clear success/pending/failed
 * status for reconciliation.
 */
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { Payment } from "@/lib/types";
import { formatGHS } from "@/lib/money";
import { EmptyState, ErrorNote, PageSpinner, StatusBadge } from "@/components/ui";

export default function AdminPaymentsPage() {
  const [payments, setPayments] = useState<Payment[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Payment[]>("/payments")
      .then(setPayments)
      .catch(() => setError("Could not load payments"));
  }, []);

  if (error) return <ErrorNote message={error} />;
  if (payments === null) return <PageSpinner />;

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Payments</h1>
      <p className="mt-1 text-sm text-muted">
        Every Mobile Money charge, linked to its booking or order. Funds settle to the salon&apos;s
        registered MoMo account.
      </p>

      {payments.length === 0 ? (
        <div className="mt-6">
          <EmptyState title="No payments yet" />
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-line">
          <table className="w-full min-w-160 bg-surface text-sm">
            <thead>
              <tr className="border-b border-line text-left text-muted">
                <th className="px-4 py-3 font-medium">Reference</th>
                <th className="px-4 py-3 font-medium">For</th>
                <th className="px-4 py-3 font-medium">Amount</th>
                <th className="px-4 py-3 font-medium">MoMo number</th>
                <th className="px-4 py-3 font-medium">When</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((payment) => (
                <tr key={payment.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 font-mono text-xs">{payment.reference}</td>
                  <td className="px-4 py-3">
                    {payment.type === "BOOKING"
                      ? `Booking — ${payment.booking?.service.name ?? "?"}`
                      : "Product order"}
                  </td>
                  <td className="px-4 py-3 font-medium">{formatGHS(payment.amountMinor)}</td>
                  <td className="px-4 py-3">{payment.momoNumber ?? "—"}</td>
                  <td className="px-4 py-3 text-muted">
                    {new Date(payment.createdAt).toLocaleString("en-GH")}
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={payment.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
