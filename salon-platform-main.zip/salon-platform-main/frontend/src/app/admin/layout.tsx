"use client";

/**
 * Admin area shell (US-11): guards every /admin route client-side
 * (redirecting non-admins away — the API enforces the same rule
 * server-side) and renders the section nav: sidebar on desktop,
 * horizontally scrollable pills on mobile.
 */
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { PageSpinner, cx } from "@/components/ui";

const LINKS = [
  { href: "/admin", label: "Overview", exact: true },
  { href: "/admin/appointments", label: "Appointments" },
  { href: "/admin/services", label: "Services" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/customers", label: "Customers" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/settings", label: "Settings" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (loading) return;
    if (!user) router.replace("/login?next=/admin");
    else if (user.role !== "ADMIN") router.replace("/");
  }, [loading, user, router]);

  if (loading || !user || user.role !== "ADMIN") return <PageSpinner />;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 lg:flex-row">
      <nav
        aria-label="Admin"
        className="flex gap-1 overflow-x-auto pb-1 lg:w-48 lg:flex-col lg:pb-0"
      >
        {LINKS.map((link) => {
          const active = link.exact ? pathname === link.href : pathname.startsWith(link.href);
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cx(
                "rounded-full px-4 py-2 text-sm font-medium whitespace-nowrap transition-colors",
                active
                  ? "bg-primary text-white"
                  : "text-muted hover:bg-primary-soft/60 hover:text-ink",
              )}
            >
              {link.label}
            </Link>
          );
        })}
      </nav>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}
