"use client";

/**
 * Admin settings: the owner's own account security. The admin layout
 * already guarantees only admins reach this page.
 */
import { ChangePasswordForm } from "@/components/change-password-form";
import { ProfileForm } from "@/components/profile-form";

export default function AdminSettingsPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Settings</h1>
      <p className="mt-1 text-sm text-muted">Manage your admin account.</p>

      <div className="mt-6 grid gap-6">
        <ProfileForm />
        <ChangePasswordForm />
      </div>
    </div>
  );
}
