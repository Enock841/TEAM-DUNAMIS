"use client";

/**
 * Admin category management (US-06): create categories and tune each
 * one's daily booking cap. Cap changes affect new bookings only.
 */
import { useEffect, useState } from "react";
import { api, ApiClientError, refreshPublicPages } from "@/lib/api";
import type { Category } from "@/lib/types";
import { Button, Card, ErrorNote, Input, PageSpinner } from "@/components/ui";

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [newName, setNewName] = useState("");
  const [newCap, setNewCap] = useState(3);
  const [busy, setBusy] = useState(false);

  const load = () =>
    api<Category[]>("/categories", { auth: false })
      .then(setCategories)
      .catch(() => setError("Could not load categories"));

  useEffect(() => {
    void load();
  }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/categories", { method: "POST", body: { name: newName, dailyCap: newCap } });
      setNewName("");
      setNewCap(3);
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Create failed");
    } finally {
      setBusy(false);
    }
  }

  async function updateCap(id: string, dailyCap: number) {
    setError(null);
    try {
      await api(`/categories/${id}`, { method: "PUT", body: { dailyCap } });
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Update failed");
    }
  }

  async function remove(category: Category) {
    if (!window.confirm(`Remove the "${category.name}" category?`)) return;
    setError(null);
    try {
      await api(`/categories/${category.id}`, { method: "DELETE" });
      refreshPublicPages();
      await load();
    } catch (err) {
      // 409 = category still has services; surface the server's explanation
      setError(err instanceof ApiClientError ? err.message : "Delete failed");
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Service categories</h1>
      <p className="mt-1 text-sm text-muted">
        The daily cap is the maximum bookings accepted per day across all services in a category.
        Changes apply to new bookings only.
      </p>

      {error && (
        <div className="mt-4">
          <ErrorNote message={error} />
        </div>
      )}

      <Card className="mt-6">
        <form onSubmit={create} className="flex flex-wrap items-end gap-3">
          <div className="min-w-40 flex-1">
            <Input
              id="new-cat-name"
              label="New category name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              required
              minLength={2}
            />
          </div>
          <div className="w-32">
            <Input
              id="new-cat-cap"
              label="Daily cap"
              type="number"
              min={1}
              max={100}
              value={newCap}
              onChange={(e) => setNewCap(Number(e.target.value))}
              required
            />
          </div>
          <Button type="submit" loading={busy}>
            Add category
          </Button>
        </form>
      </Card>

      {categories === null ? (
        <PageSpinner />
      ) : (
        <ul className="mt-6 space-y-3">
          {categories.map((category) => (
            <CategoryRow
              key={category.id}
              category={category}
              onSave={updateCap}
              onRemove={remove}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

function CategoryRow({
  category,
  onSave,
  onRemove,
}: {
  category: Category;
  onSave: (id: string, cap: number) => Promise<void>;
  onRemove: (category: Category) => Promise<void>;
}) {
  const [cap, setCap] = useState(category.dailyCap);
  const dirty = cap !== category.dailyCap;

  return (
    <li className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-5">
      <p className="font-medium">{category.name}</p>
      <div className="flex items-center gap-3">
        <label htmlFor={`cap-${category.id}`} className="text-sm text-muted">
          Max/day
        </label>
        <input
          id={`cap-${category.id}`}
          type="number"
          min={1}
          max={100}
          value={cap}
          onChange={(e) => setCap(Number(e.target.value))}
          className="w-20 rounded-xl border border-line bg-surface px-3 py-2 text-sm focus:border-primary focus:outline-none"
        />
        <Button
          variant="secondary"
          className="px-4 py-2 text-xs"
          disabled={!dirty}
          onClick={() => onSave(category.id, cap)}
        >
          Save
        </Button>
        <Button
          variant="danger"
          className="px-4 py-2 text-xs"
          onClick={() => onRemove(category)}
        >
          Remove
        </Button>
      </div>
    </li>
  );
}
