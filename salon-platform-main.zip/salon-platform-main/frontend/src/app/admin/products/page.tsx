"use client";

/**
 * Admin product & inventory management (US-08 AC3, US-11): create/edit
 * products and adjust stock. Stock edits go through the dedicated audited
 * endpoint — the general edit form deliberately can't change stock.
 */
import { useEffect, useState } from "react";
import { api, ApiClientError, refreshPublicPages } from "@/lib/api";
import type { Product } from "@/lib/types";
import { formatGHS } from "@/lib/money";
import { Badge, Button, Card, ErrorNote, Input, PageSpinner } from "@/components/ui";
import { ImageField } from "@/components/image-field";

interface ProductForm {
  id?: string;
  name: string;
  description: string;
  priceGhs: string;
  stockQty: string;
  imageUrl: string;
  active: boolean;
}

const emptyForm: ProductForm = {
  name: "",
  description: "",
  priceGhs: "",
  stockQty: "0",
  imageUrl: "",
  active: true,
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[] | null>(null);
  const [form, setForm] = useState<ProductForm | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () =>
    api<Product[]>("/products/all")
      .then(setProducts)
      .catch(() => setError("Could not load products"));

  useEffect(() => {
    void load();
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setBusy(true);
    setError(null);
    const body = {
      name: form.name,
      description: form.description,
      price: Math.round(Number(form.priceGhs) * 100),
      imageUrl: form.imageUrl.trim() || null,
      active: form.active,
      ...(form.id ? {} : { stockQty: Number(form.stockQty) }),
    };
    try {
      if (form.id) await api(`/products/${form.id}`, { method: "PUT", body });
      else await api("/products", { method: "POST", body });
      setForm(null);
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function adjustStock(product: Product) {
    const answer = window.prompt(
      `New stock quantity for "${product.name}" (current: ${product.stockQty})`,
      String(product.stockQty),
    );
    if (answer === null) return;
    const stockQty = Number(answer);
    if (!Number.isInteger(stockQty) || stockQty < 0) {
      setError("Stock must be a whole number of 0 or more");
      return;
    }
    try {
      await api(`/products/${product.id}/stock`, {
        method: "PUT",
        body: { stockQty, reason: "manual adjustment from dashboard" },
      });
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Stock update failed");
    }
  }

  async function toggleActive(product: Product) {
    setError(null);
    try {
      await api(`/products/${product.id}`, {
        method: "PUT",
        body: { active: !product.active },
      });
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Update failed");
    }
  }

  async function remove(product: Product) {
    if (!window.confirm(`Delete "${product.name}"? It will disappear from the shop.`)) return;
    setError(null);
    try {
      await api(`/products/${product.id}`, { method: "DELETE" });
      refreshPublicPages();
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Delete failed");
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-semibold">Products &amp; inventory</h1>
        <Button onClick={() => setForm(emptyForm)}>New product</Button>
      </div>
      <p className="mt-1 text-sm text-muted">
        Stock decreases automatically when a customer pays. Use “Adjust stock” for restocks and
        corrections — every change is logged.
      </p>

      {error && (
        <div className="mt-4">
          <ErrorNote message={error} />
        </div>
      )}

      {form && (
        <Card className="mt-6">
          <form onSubmit={save} className="grid gap-4 sm:grid-cols-2">
            <Input
              id="prod-name"
              label="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
              minLength={2}
            />
            <Input
              id="prod-price"
              label="Price (GH₵)"
              type="number"
              min={0}
              step="0.01"
              value={form.priceGhs}
              onChange={(e) => setForm({ ...form, priceGhs: e.target.value })}
              required
            />
            {!form.id && (
              <Input
                id="prod-stock"
                label="Starting stock"
                type="number"
                min={0}
                value={form.stockQty}
                onChange={(e) => setForm({ ...form, stockQty: e.target.value })}
                required
              />
            )}
            <ImageField
              label="Photo (optional)"
              value={form.imageUrl}
              onChange={(imageUrl) => setForm({ ...form, imageUrl })}
            />
            <div className="flex flex-col gap-1.5 sm:col-span-2">
              <label htmlFor="prod-desc" className="text-sm font-medium">
                Description
              </label>
              <textarea
                id="prod-desc"
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="rounded-xl border border-line bg-surface px-4 py-2.5 text-sm focus:border-primary focus:outline-none"
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(e) => setForm({ ...form, active: e.target.checked })}
              />
              Visible in shop
            </label>
            <div className="flex justify-end gap-2 sm:col-span-2">
              <Button type="button" variant="ghost" onClick={() => setForm(null)}>
                Cancel
              </Button>
              <Button type="submit" loading={busy}>
                {form.id ? "Save changes" : "Create product"}
              </Button>
            </div>
          </form>
        </Card>
      )}

      {products === null ? (
        <PageSpinner />
      ) : (
        <ul className="mt-6 space-y-3">
          {products.map((product) => (
            <li
              key={product.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-5"
            >
              <div>
                <p className="font-medium">
                  {product.name}
                  {!product.active && (
                    <span className="ml-2">
                      <Badge tone="neutral">Hidden</Badge>
                    </span>
                  )}
                </p>
                <p className="text-sm text-muted">
                  {formatGHS(product.price)} ·{" "}
                  {product.stockQty === 0 ? (
                    <span className="text-danger">Out of stock</span>
                  ) : (
                    `${product.stockQty} in stock`
                  )}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  className="px-4 py-2 text-xs"
                  onClick={() => adjustStock(product)}
                >
                  Adjust stock
                </Button>
                <Button
                  variant="ghost"
                  className="px-4 py-2 text-xs"
                  onClick={() =>
                    setForm({
                      id: product.id,
                      name: product.name,
                      description: product.description,
                      priceGhs: String(product.price / 100),
                      stockQty: String(product.stockQty),
                      imageUrl: product.imageUrl ?? "",
                      active: product.active,
                    })
                  }
                >
                  Edit
                </Button>
                <Button
                  variant="ghost"
                  className="px-4 py-2 text-xs"
                  onClick={() => toggleActive(product)}
                >
                  {product.active ? "Hide" : "Show"}
                </Button>
                <Button
                  variant="danger"
                  className="px-4 py-2 text-xs"
                  onClick={() => remove(product)}
                >
                  Delete
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
