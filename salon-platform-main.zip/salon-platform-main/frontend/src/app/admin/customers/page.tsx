"use client";

/**
 * Admin customer directory (US-12): debounced search over name/phone/
 * email with booking and order counts; rows link to the full profile.
 */
import Link from "next/link";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { CustomerSummary } from "@/lib/types";
import { EmptyState, Input, PageSpinner } from "@/components/ui";

export default function AdminCustomersPage() {
  const [search, setSearch] = useState("");
  const [customers, setCustomers] = useState<CustomerSummary[] | null>(null);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      const query = search.trim() ? `?search=${encodeURIComponent(search.trim())}` : "";
      api<CustomerSummary[]>(`/admin/customers${query}`)
        .then(setCustomers)
        .catch(() => setCustomers([]));
    }, 300);
    return () => window.clearTimeout(handle);
  }, [search]);

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Customers</h1>
      <div className="mt-4 max-w-sm">
        <Input
          id="customer-search"
          placeholder="Search by name, phone, or email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search customers"
        />
      </div>

      {customers === null ? (
        <PageSpinner />
      ) : customers.length === 0 ? (
        <div className="mt-6">
          <EmptyState title="No customers found" />
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {customers.map((customer) => (
            <li key={customer.id}>
              <Link
                href={`/admin/customers/${customer.id}`}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-5 transition-shadow hover:shadow-md"
              >
                <div>
                  <p className="font-medium">{customer.name}</p>
                  <p className="text-sm text-muted">
                    {customer.phone}
                    {customer.email ? ` · ${customer.email}` : ""}
                  </p>
                </div>
                <p className="text-sm text-muted">
                  {customer._count.bookings} bookings · {customer._count.orders} orders
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
