"use client";

/**
 * Admin customer profile (US-12 AC1/AC2): contact details plus the full
 * retained history of bookings and orders for personalized service.
 */
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { formatGHS } from "@/lib/money";
import { ErrorNote, PageSpinner, StatusBadge } from "@/components/ui";

interface CustomerDetail {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  createdAt: string;
  bookings: {
    id: string;
    date: string;
    timeSlot: string;
    status: string;
    service: { name: string; category: { name: string } };
  }[];
  orders: {
    id: string;
    status: string;
    totalMinor: number;
    createdAt: string;
    items: { id: string; quantity: number; product: { name: string } }[];
  }[];
}

export default function AdminCustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [customer, setCustomer] = useState<CustomerDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<CustomerDetail>(`/admin/customers/${id}`)
      .then(setCustomer)
      .catch(() => setError("Could not load this customer"));
  }, [id]);

  if (error) return <ErrorNote message={error} />;
  if (!customer) return <PageSpinner />;

  return (
    <div>
      <Link href="/admin/customers" className="text-sm text-muted hover:text-primary-strong">
        ← All customers
      </Link>
      <h1 className="mt-2 font-display text-2xl font-semibold">{customer.name}</h1>
      <p className="text-muted">
        {customer.phone}
        {customer.email ? ` · ${customer.email}` : ""} · joined{" "}
        {new Date(customer.createdAt).toLocaleDateString("en-GH")}
      </p>

      <h2 className="mt-8 font-display text-lg font-semibold">Bookings</h2>
      {customer.bookings.length === 0 ? (
        <p className="mt-2 text-sm text-muted">No bookings yet.</p>
      ) : (
        <ul className="mt-3 space-y-2">
          {customer.bookings.map((booking) => (
            <li
              key={booking.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-surface px-4 py-3 text-sm"
            >
              <span>
                {booking.service.name}{" "}
                <span className="text-muted">({booking.service.category.name})</span> ·{" "}
                {new Date(booking.date).toLocaleDateString("en-GH")} {booking.timeSlot}
              </span>
              <StatusBadge status={booking.status} />
            </li>
          ))}
        </ul>
      )}

      <h2 className="mt-8 font-display text-lg font-semibold">Orders</h2>
      {customer.orders.length === 0 ? (
        <p className="mt-2 text-sm text-muted">No orders yet.</p>
      ) : (
        <ul className="mt-3 space-y-2">
          {customer.orders.map((order) => (
            <li key={order.id} className="rounded-xl border border-line bg-surface px-4 py-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span>
                  {new Date(order.createdAt).toLocaleDateString("en-GH")} ·{" "}
                  {formatGHS(order.totalMinor)}
                </span>
                <StatusBadge status={order.status} />
              </div>
              <p className="mt-1 text-muted">
                {order.items.map((i) => `${i.product.name} × ${i.quantity}`).join(", ")}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
