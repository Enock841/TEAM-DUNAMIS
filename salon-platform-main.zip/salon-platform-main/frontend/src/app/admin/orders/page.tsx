"use client";

/**
 * Admin orders view (US-11): every order with customer, items, and
 * status; paid orders can be marked fulfilled after pickup/delivery.
 */
import { useEffect, useState } from "react";
import { api, ApiClientError } from "@/lib/api";
import type { Order } from "@/lib/types";
import { formatGHS } from "@/lib/money";
import { Button, EmptyState, ErrorNote, PageSpinner, StatusBadge } from "@/components/ui";

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = () =>
    api<Order[]>("/orders")
      .then(setOrders)
      .catch(() => setError("Could not load orders"));

  useEffect(() => {
    void load();
  }, []);

  async function setStatus(id: string, status: "FULFILLED" | "CANCELLED") {
    setError(null);
    try {
      await api(`/orders/${id}/status`, { method: "PUT", body: { status } });
      await load();
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Update failed");
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Orders</h1>

      {error && (
        <div className="mt-4">
          <ErrorNote message={error} />
        </div>
      )}

      {orders === null ? (
        <PageSpinner />
      ) : orders.length === 0 ? (
        <div className="mt-6">
          <EmptyState title="No orders yet" hint="Customer purchases will appear here." />
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {orders.map((order) => (
            <li key={order.id} className="rounded-2xl border border-line bg-surface p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-medium">
                    {order.user?.name}{" "}
                    <span className="text-sm font-normal text-muted">({order.user?.phone})</span>
                  </p>
                  <p className="text-sm text-muted">
                    {new Date(order.createdAt).toLocaleString("en-GH")} ·{" "}
                    {formatGHS(order.totalMinor)}
                  </p>
                </div>
                <StatusBadge status={order.status} />
              </div>
              <ul className="mt-2 text-sm text-muted">
                {order.items.map((item) => (
                  <li key={item.id}>
                    {item.product.name} × {item.quantity} —{" "}
                    {formatGHS(item.unitPriceMinor * item.quantity)}
                  </li>
                ))}
              </ul>
              {order.status === "PAID" && (
                <div className="mt-3 flex gap-2">
                  <Button
                    variant="secondary"
                    className="px-4 py-2 text-xs"
                    onClick={() => setStatus(order.id, "FULFILLED")}
                  >
                    Mark fulfilled
                  </Button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
