"use client";

/** Admin overview (US-11): at-a-glance business numbers for the day. */
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { AdminStats } from "@/lib/types";
import { formatGHS } from "@/lib/money";
import { Card, PageSpinner, ErrorNote } from "@/components/ui";

export default function AdminOverviewPage() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<AdminStats>("/admin/stats")
      .then(setStats)
      .catch(() => setError("Could not load dashboard stats"));
  }, []);

  if (error) return <ErrorNote message={error} />;
  if (!stats) return <PageSpinner />;

  const cards = [
    { label: "Appointments today", value: stats.bookingsToday },
    { label: "Upcoming confirmed", value: stats.upcomingBookings },
    { label: "Orders to fulfil", value: stats.ordersAwaitingFulfilment },
    { label: "Low-stock products", value: stats.lowStockProducts },
    { label: "Customers", value: stats.totalCustomers },
    { label: "Total received", value: formatGHS(stats.totalRevenueMinor) },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Overview</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((card) => (
          <Card key={card.label}>
            <p className="text-sm text-muted">{card.label}</p>
            <p className="mt-1 font-display text-3xl font-semibold text-primary-strong">
              {card.value}
            </p>
          </Card>
        ))}
      </div>
    </div>
  );
}
