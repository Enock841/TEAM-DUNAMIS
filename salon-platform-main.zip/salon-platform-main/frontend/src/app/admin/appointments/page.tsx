"use client";

/**
 * Admin appointments view (US-11 AC3): date-filterable list with customer
 * contact details and one-click status actions (complete / no-show /
 * cancel). Cancelling frees the day's cap slot for that category.
 */
import { useCallback, useEffect, useState } from "react";
import { api, ApiClientError } from "@/lib/api";
import type { Booking, BookingStatus } from "@/lib/types";
import { Button, EmptyState, ErrorNote, Input, PageSpinner, StatusBadge } from "@/components/ui";

const ACTIONS: { label: string; to: BookingStatus }[] = [
  { label: "Complete", to: "COMPLETED" },
  { label: "No-show", to: "NO_SHOW" },
  { label: "Cancel", to: "CANCELLED" },
];

export default function AdminAppointmentsPage() {
  const [date, setDate] = useState("");
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const query = date ? `?date=${date}` : "";
      setBookings(await api<Booking[]>(`/bookings${query}`));
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Could not load appointments");
    }
  }, [date]);

  useEffect(() => {
    // Debounced so changing the date filter doesn't spam requests
    const handle = window.setTimeout(() => void load(), 150);
    return () => window.clearTimeout(handle);
  }, [load]);

  async function setStatus(id: string, status: BookingStatus) {
    try {
      await api(`/bookings/${id}/status`, { method: "PUT", body: { status } });
      void load();
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Update failed");
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="font-display text-2xl font-semibold">Appointments</h1>
        <div className="w-44">
          <Input
            id="filter-date"
            label="Filter by date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
      </div>

      {error && (
        <div className="mt-4">
          <ErrorNote message={error} />
        </div>
      )}

      {bookings === null ? (
        <PageSpinner />
      ) : bookings.length === 0 ? (
        <div className="mt-6">
          <EmptyState title="No appointments" hint={date ? `Nothing booked for ${date}.` : undefined} />
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {bookings.map((b) => (
            <li key={b.id} className="rounded-2xl border border-line bg-surface p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-medium">
                    {b.service.name}
                    <span className="ml-2 text-sm font-normal text-muted">
                      {b.service.category?.name}
                    </span>
                  </p>
                  <p className="text-sm text-muted">
                    {new Date(b.date).toLocaleDateString("en-GH", {
                      weekday: "short",
                      day: "numeric",
                      month: "short",
                    })}{" "}
                    · {b.timeSlot} · {b.user?.name} ({b.user?.phone})
                  </p>
                </div>
                <StatusBadge status={b.status} />
              </div>
              {(b.status === "CONFIRMED" || b.status === "PENDING_PAYMENT") && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {ACTIONS.map((action) => (
                    <Button
                      key={action.to}
                      variant={action.to === "COMPLETED" ? "secondary" : "ghost"}
                      className="px-3 py-1.5 text-xs"
                      onClick={() => setStatus(b.id, action.to)}
                    >
                      {action.label}
                    </Button>
                  ))}
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
