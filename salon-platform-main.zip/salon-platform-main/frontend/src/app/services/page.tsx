/**
 * Public services catalog (US-03): server-rendered and grouped by
 * category, showing image, description, and price range per service.
 * Inactive services are already filtered out by the API.
 */
import type { Metadata } from "next";
import Link from "next/link";
import { serverGet } from "@/lib/server-api";
import type { Service } from "@/lib/types";
import { formatRange } from "@/lib/money";

export const metadata: Metadata = {
  title: "Services & Prices",
  description:
    "Braids, twists, natural hair care, and event styling — see photos, price ranges, and book your appointment online.",
};

export default async function ServicesPage() {
  const services = await serverGet<Service[]>("/services");

  if (!services) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16">
        <h1 className="font-display text-3xl font-semibold">Our services</h1>
        <p className="mt-6 rounded-2xl border border-dashed border-line p-10 text-center text-muted">
          We couldn&apos;t load the service list right now. Please refresh in a moment.
        </p>
      </div>
    );
  }

  const byCategory = new Map<string, Service[]>();
  for (const service of services) {
    const list = byCategory.get(service.category.name) ?? [];
    list.push(service);
    byCategory.set(service.category.name, list);
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <h1 className="font-display text-3xl font-semibold">Our services</h1>
      <p className="mt-2 max-w-xl text-muted">
        Every price is a range — the final cost depends on length and extras, agreed before we
        start. Book online to reserve your day.
      </p>

      {[...byCategory.entries()].map(([category, list]) => (
        <section key={category} className="mt-10">
          <h2 className="font-display text-xl font-semibold text-primary-strong">{category}</h2>
          <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((service) => (
              <Link
                key={service.id}
                href={`/services/${service.id}`}
                className="group flex flex-col overflow-hidden rounded-2xl border border-line bg-surface transition-shadow hover:shadow-md"
              >
                <div className="flex h-40 items-center justify-center bg-surface-2 text-5xl">
                  {service.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={service.imageUrl}
                      alt={service.name}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <span aria-hidden>💇🏾‍♀️</span>
                  )}
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="font-medium group-hover:text-primary-strong">{service.name}</h3>
                  <p className="mt-1 line-clamp-2 flex-1 text-sm text-muted">
                    {service.description}
                  </p>
                  <p className="mt-3 text-sm font-semibold text-primary-strong">
                    {formatRange(service.priceMin, service.priceMax)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
