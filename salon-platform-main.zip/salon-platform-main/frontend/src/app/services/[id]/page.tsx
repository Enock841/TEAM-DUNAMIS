/**
 * Service detail page: server-rendered content (with per-service SEO
 * metadata) alongside the interactive client-side BookingWidget.
 */
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { serverGet } from "@/lib/server-api";
import type { Service } from "@/lib/types";
import { formatRange } from "@/lib/money";
import { BookingWidget } from "@/components/booking-widget";

interface Props {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const service = await serverGet<Service>(`/services/${id}`);
  if (!service) return { title: "Service" };
  return {
    title: service.name,
    description: `${service.description.slice(0, 150)} — ${formatRange(service.priceMin, service.priceMax)}. Book online.`,
  };
}

export default async function ServiceDetailPage({ params }: Props) {
  const { id } = await params;
  const service = await serverGet<Service>(`/services/${id}`);
  if (!service) notFound();

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <div className="grid gap-10 lg:grid-cols-[1fr_400px]">
        <div>
          <p className="text-sm font-medium text-primary-strong">{service.category.name}</p>
          <h1 className="mt-1 font-display text-3xl font-semibold">{service.name}</h1>
          <p className="mt-3 text-xl font-semibold text-primary-strong">
            {formatRange(service.priceMin, service.priceMax)}
          </p>

          <div className="mt-6 flex h-64 items-center justify-center overflow-hidden rounded-2xl bg-surface-2 text-7xl sm:h-80">
            {service.imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={service.imageUrl}
                alt={service.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <span aria-hidden>💇🏾‍♀️</span>
            )}
          </div>

          <h2 className="mt-8 font-display text-lg font-semibold">About this service</h2>
          <p className="mt-2 leading-relaxed whitespace-pre-line text-muted">
            {service.description || "Ask us anything about this style when you visit."}
          </p>
          <p className="mt-4 rounded-xl bg-surface-2 px-4 py-3 text-sm text-muted">
            💡 The exact price within the range depends on hair length and extras — we&apos;ll
            confirm before starting. Only {service.category.dailyCap}{" "}
            {service.category.name.toLowerCase()} appointments are taken per day so every client
            gets unhurried attention.
          </p>
        </div>

        <div className="lg:sticky lg:top-24 lg:self-start">
          <BookingWidget service={service} />
        </div>
      </div>
    </div>
  );
}
