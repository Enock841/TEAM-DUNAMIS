"use client";

/**
 * Signup page (US-01): name + phone (unique) + optional email + password.
 * On success the user is logged in immediately and lands on their account.
 */
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { ApiClientError } from "@/lib/api";
import { Button, ErrorNote, Input, PasswordInput } from "@/components/ui";

export default function RegisterPage() {
  const { register } = useAuth();
  const router = useRouter();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await register({
        name,
        phone: phone.replace(/\s+/g, ""),
        email: email.trim() || undefined,
        password,
      });
      router.push("/account");
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Sign up failed");
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <h1 className="font-display text-3xl font-semibold">Create your account</h1>
      <p className="mt-2 text-muted">
        Book appointments, track orders, and keep your visit history in one place.
      </p>
      <form onSubmit={submit} className="mt-8 space-y-4 rounded-2xl border border-line bg-surface p-6">
        <Input
          id="name"
          label="Full name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoComplete="name"
          required
        />
        <Input
          id="phone"
          label="Phone number"
          inputMode="tel"
          placeholder="e.g. 0241234567"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          autoComplete="tel"
          required
        />
        <Input
          id="email"
          label="Email (optional)"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
        />
        <PasswordInput
          id="password"
          label="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="new-password"
          minLength={8}
          required
        />
        <p className="text-xs text-muted">At least 8 characters.</p>
        {error && <ErrorNote message={error} />}
        <Button type="submit" className="w-full" loading={busy}>
          Sign up
        </Button>
      </form>
      <p className="mt-4 text-center text-sm text-muted">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-primary-strong hover:underline">
          Log in
        </Link>
      </p>
    </div>
  );
}
