"use client";

/**
 * Customer account page (US-02 AC3): tabs for booking history and order
 * history. Redirects to login when no session exists.
 */
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import type { Booking, Order } from "@/lib/types";
import { formatGHS } from "@/lib/money";
import { EmptyState, PageSpinner, StatusBadge } from "@/components/ui";

export default function AccountPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [tab, setTab] = useState<"bookings" | "orders">("bookings");

  useEffect(() => {
    if (!loading && !user) router.replace("/login?next=/account");
  }, [loading, user, router]);

  useEffect(() => {
    if (!user) return;
    api<Booking[]>("/bookings/me").then(setBookings).catch(() => setBookings([]));
    api<Order[]>("/orders/me").then(setOrders).catch(() => setOrders([]));
  }, [user]);

  if (loading || !user) return <PageSpinner />;

  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold">
            Hi, {user.name.split(" ")[0]} 👋
          </h1>
          <p className="mt-1 text-muted">{user.phone}</p>
        </div>
        <Link
          href="/account/settings"
          className="rounded-full bg-surface-2 px-5 py-2.5 text-sm font-medium text-muted hover:text-ink"
        >
          ⚙︎ Settings
        </Link>
      </div>

      <div className="mt-8 flex gap-2" role="tablist" aria-label="Account sections">
        {(["bookings", "orders"] as const).map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={`rounded-full px-5 py-2 text-sm font-medium capitalize cursor-pointer ${
              tab === t ? "bg-primary text-white" : "bg-surface-2 text-muted hover:text-ink"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "bookings" &&
        (bookings === null ? (
          <PageSpinner />
        ) : bookings.length === 0 ? (
          <div className="mt-6">
            <EmptyState
              title="No bookings yet"
              hint="Your future and past appointments will appear here."
              action={
                <Link
                  href="/services"
                  className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-white hover:bg-primary-strong"
                >
                  Book a service
                </Link>
              }
            />
          </div>
        ) : (
          <ul className="mt-6 space-y-3">
            {bookings.map((b) => (
              <li
                key={b.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-5"
              >
                <div>
                  <p className="font-medium">{b.service.name}</p>
                  <p className="text-sm text-muted">
                    {new Date(b.date).toLocaleDateString("en-GH", {
                      weekday: "short",
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                    })}{" "}
                    · {b.timeSlot}
                  </p>
                </div>
                <StatusBadge status={b.status} />
              </li>
            ))}
          </ul>
        ))}

      {tab === "orders" &&
        (orders === null ? (
          <PageSpinner />
        ) : orders.length === 0 ? (
          <div className="mt-6">
            <EmptyState
              title="No orders yet"
              hint="Products you purchase will appear here."
              action={
                <Link
                  href="/products"
                  className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-white hover:bg-primary-strong"
                >
                  Shop products
                </Link>
              }
            />
          </div>
        ) : (
          <ul className="mt-6 space-y-3">
            {orders.map((o) => (
              <li key={o.id} className="rounded-2xl border border-line bg-surface p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="font-medium">
                    {new Date(o.createdAt).toLocaleDateString("en-GH", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                    })}{" "}
                    · {formatGHS(o.totalMinor)}
                  </p>
                  <StatusBadge status={o.status} />
                </div>
                <ul className="mt-2 text-sm text-muted">
                  {o.items.map((item) => (
                    <li key={item.id}>
                      {item.product.name} × {item.quantity}
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        ))}
    </div>
  );
}
