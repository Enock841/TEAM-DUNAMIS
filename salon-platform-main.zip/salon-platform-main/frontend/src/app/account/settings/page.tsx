"use client";

/**
 * Account settings: profile summary and password change. Available to
 * every signed-in user; admins also reach this via Admin → Settings.
 */
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { Card, PageSpinner } from "@/components/ui";
import { ChangePasswordForm } from "@/components/change-password-form";
import { ProfileForm } from "@/components/profile-form";

export default function AccountSettingsPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.replace("/login?next=/account/settings");
  }, [loading, user, router]);

  if (loading || !user) return <PageSpinner />;

  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <Link href="/account" className="text-sm text-muted hover:text-primary-strong">
        ← Back to my account
      </Link>
      <h1 className="mt-2 font-display text-3xl font-semibold">Settings</h1>

      <div className="mt-8 grid gap-6">
        <ProfileForm />

        <Card>
          <h2 className="font-display text-lg font-semibold">Account type</h2>
          <p className="mt-2 text-sm font-medium capitalize">{user.role.toLowerCase()}</p>
        </Card>

        <ChangePasswordForm />
      </div>
    </div>
  );
}
