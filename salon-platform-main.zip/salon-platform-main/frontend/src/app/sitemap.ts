import type { MetadataRoute } from "next";
import { serverGet } from "@/lib/server-api";
import type { Service } from "@/lib/types";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

/** sitemap.xml (US-13): static pages plus one URL per active service. */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const services = (await serverGet<Service[]>("/services")) ?? [];

  return [
    { url: SITE_URL, changeFrequency: "weekly", priority: 1 },
    { url: `${SITE_URL}/services`, changeFrequency: "weekly", priority: 0.9 },
    { url: `${SITE_URL}/products`, changeFrequency: "weekly", priority: 0.8 },
    ...services.map((service) => ({
      url: `${SITE_URL}/services/${service.id}`,
      changeFrequency: "weekly" as const,
      priority: 0.7,
    })),
  ];
}
