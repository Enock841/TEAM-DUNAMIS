"use client";

/**
 * Cart + checkout (US-07/US-09), a three-step flow on one page:
 *   cart — edit quantities (clamped to stock), see the running total
 *   pay  — order created server-side (repriced from the live catalog),
 *          then charged via Mobile Money
 *   done — stock has been deducted and the order is PAID (US-08)
 */
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useCart } from "@/lib/cart-context";
import { useAuth } from "@/lib/auth-context";
import { api, ApiClientError } from "@/lib/api";
import { formatGHS } from "@/lib/money";
import type { Order } from "@/lib/types";
import { Button, EmptyState, ErrorNote, Input } from "@/components/ui";

type Step = "cart" | "pay" | "done";

export default function CartPage() {
  const { items, totalMinor, setQuantity, remove, clear } = useCart();
  const { user } = useAuth();
  const router = useRouter();

  const [step, setStep] = useState<Step>("cart");
  const [order, setOrder] = useState<Order | null>(null);
  const [momoNumber, setMomoNumber] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);

  async function checkout() {
    if (!user) {
      router.push("/login?next=/cart");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ order: Order }>("/orders", {
        method: "POST",
        body: { items: items.map((i) => ({ productId: i.product.id, quantity: i.quantity })) },
      });
      setOrder(res.order);
      setMomoNumber(user.phone);
      setStep("pay");
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Checkout failed");
    } finally {
      setBusy(false);
    }
  }

  async function pay() {
    if (!order) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ reference: string; status: string }>("/payments/initiate", {
        method: "POST",
        body: { type: "order", refId: order.id, momoNumber },
      });
      setPaymentStatus(res.status);
      if (res.status === "FAILED") {
        setError("Payment was declined. Please check the number and try again.");
      } else {
        clear();
        setStep("done");
      }
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Payment failed");
    } finally {
      setBusy(false);
    }
  }

  if (step === "done") {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <p className="text-5xl" aria-hidden>
          🎉
        </p>
        <h1 className="mt-3 font-display text-2xl font-semibold">
          {paymentStatus === "SUCCESS" ? "Order paid — thank you!" : "Almost there!"}
        </h1>
        <p className="mt-2 text-muted">
          {paymentStatus === "SUCCESS"
            ? "We've received your payment and are preparing your order."
            : "Approve the payment prompt on your phone to complete the order."}
        </p>
        <Button className="mt-6" onClick={() => router.push("/account")}>
          View my orders
        </Button>
      </div>
    );
  }

  if (step === "pay" && order) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16">
        <h1 className="font-display text-2xl font-semibold">Pay with Mobile Money</h1>
        <div className="mt-6 rounded-2xl border border-line bg-surface p-6">
          <ul className="space-y-2 text-sm">
            {order.items.map((item) => (
              <li key={item.id} className="flex justify-between">
                <span>
                  {item.product.name} × {item.quantity}
                </span>
                <span>{formatGHS(item.unitPriceMinor * item.quantity)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex justify-between border-t border-line pt-4 font-semibold">
            <span>Total</span>
            <span className="text-primary-strong">{formatGHS(order.totalMinor)}</span>
          </div>
          <div className="mt-5">
            <Input
              id="momo"
              label="Mobile Money number"
              inputMode="tel"
              value={momoNumber}
              onChange={(e) => setMomoNumber(e.target.value)}
              placeholder="e.g. 0241234567"
            />
          </div>
          {error && (
            <div className="mt-3">
              <ErrorNote message={error} />
            </div>
          )}
          <Button className="mt-5 w-full" onClick={pay} loading={busy}>
            Pay {formatGHS(order.totalMinor)}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="font-display text-3xl font-semibold">Your cart</h1>

      {items.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            title="Your cart is empty"
            hint="Browse our products and add something you love."
            action={
              <Link
                href="/products"
                className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-white hover:bg-primary-strong"
              >
                Shop products
              </Link>
            }
          />
        </div>
      ) : (
        <>
          <ul className="mt-8 space-y-4">
            {items.map(({ product, quantity }) => (
              <li
                key={product.id}
                className="flex flex-wrap items-center gap-4 rounded-2xl border border-line bg-surface p-4"
              >
                <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-surface-2 text-2xl">
                  {product.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={product.imageUrl}
                      alt=""
                      className="h-full w-full rounded-xl object-cover"
                    />
                  ) : (
                    <span aria-hidden>🧴</span>
                  )}
                </div>
                <div className="min-w-32 flex-1">
                  <p className="font-medium">{product.name}</p>
                  <p className="text-sm text-muted">{formatGHS(product.price)} each</p>
                </div>
                <div className="flex items-center gap-2" aria-label={`Quantity for ${product.name}`}>
                  <button
                    className="h-8 w-8 rounded-full border border-line hover:border-primary cursor-pointer"
                    aria-label="Decrease quantity"
                    onClick={() => setQuantity(product.id, quantity - 1)}
                  >
                    −
                  </button>
                  <span className="w-6 text-center text-sm font-medium">{quantity}</span>
                  <button
                    className="h-8 w-8 rounded-full border border-line hover:border-primary cursor-pointer disabled:opacity-40"
                    aria-label="Increase quantity"
                    disabled={quantity >= product.stockQty}
                    onClick={() => setQuantity(product.id, quantity + 1)}
                  >
                    +
                  </button>
                </div>
                <p className="w-24 text-right font-semibold">
                  {formatGHS(product.price * quantity)}
                </p>
                <button
                  className="text-sm text-danger hover:underline cursor-pointer"
                  onClick={() => remove(product.id)}
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>

          {error && (
            <div className="mt-4">
              <ErrorNote message={error} />
            </div>
          )}

          <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-surface-2 p-5">
            <p className="text-lg font-semibold">
              Total: <span className="text-primary-strong">{formatGHS(totalMinor)}</span>
            </p>
            <Button onClick={checkout} loading={busy}>
              {user ? "Checkout with MoMo" : "Log in to checkout"}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
