/**
 * Root layout: fonts (Inter body / Fraunces display), global SEO metadata
 * (US-13), and the app-wide providers (auth session + cart) wrapping the
 * shared header/footer chrome.
 */
import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/lib/auth-context";
import { CartProvider } from "@/lib/cart-context";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

const inter = Inter({ variable: "--font-body", subsets: ["latin"] });
const fraunces = Fraunces({ variable: "--font-display", subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: "Beryl’s Beauty Mark — Salon Booking & Shop",
    template: "%s · Beryl’s Beauty Mark",
  },
  description:
    "Book braids, natural hair care, and styling appointments online, and shop salon-quality hair products. Pay securely with Mobile Money.",
  keywords: ["salon", "braids", "hair", "booking", "Ghana", "Kumasi", "mobile money"],
  openGraph: {
    title: "Beryl’s Beauty Mark — Salon Booking & Shop",
    description: "Book your next hair appointment online and shop our products.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${fraunces.variable} font-sans antialiased`}>
        <AuthProvider>
          <CartProvider>
            <div className="flex min-h-screen flex-col">
              <Header />
              <main className="flex-1">{children}</main>
              <Footer />
            </div>
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
