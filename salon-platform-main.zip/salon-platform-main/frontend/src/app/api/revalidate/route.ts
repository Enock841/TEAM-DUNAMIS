import { revalidatePath } from "next/cache";
import { NextResponse } from "next/server";

/**
 * Purge the cached public catalog pages. The admin dashboard calls this
 * after creating/editing/deleting services, categories, or products so
 * changes appear immediately instead of after the 60s ISR window.
 * Deliberately unauthenticated: it can only trigger a re-fetch from the
 * API (same data the pages would show a minute later anyway).
 */
export async function POST() {
  revalidatePath("/services");
  revalidatePath("/services/[id]", "page");
  revalidatePath("/products");
  return NextResponse.json({ revalidated: true });
}
