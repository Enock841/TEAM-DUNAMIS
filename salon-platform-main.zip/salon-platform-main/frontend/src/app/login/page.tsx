"use client";

/**
 * Login page (US-02). Accepts phone or email in one field; supports a
 * ?next= redirect so flows like booking can send users back where they
 * were. Admins are routed straight to the dashboard.
 */
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { ApiClientError } from "@/lib/api";
import { Button, ErrorNote, Input, PageSpinner, PasswordInput } from "@/components/ui";

function LoginForm() {
  const { login } = useAuth();
  const router = useRouter();
  const next = useSearchParams().get("next") ?? "/account";

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const user = await login(identifier, password);
      router.push(user.role === "ADMIN" ? "/admin" : next);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Login failed");
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <Input
        id="identifier"
        label="Phone number or email"
        value={identifier}
        onChange={(e) => setIdentifier(e.target.value)}
        autoComplete="username"
        required
      />
      <PasswordInput
        id="password"
        label="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        autoComplete="current-password"
        required
      />
      {error && <ErrorNote message={error} />}
      <Button type="submit" className="w-full" loading={busy}>
        Log in
      </Button>
    </form>
  );
}

export default function LoginPage() {
  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <h1 className="font-display text-3xl font-semibold">Welcome back</h1>
      <p className="mt-2 text-muted">Log in to see your bookings and orders.</p>
      <div className="mt-8 rounded-2xl border border-line bg-surface p-6">
        <Suspense fallback={<PageSpinner />}>
          <LoginForm />
        </Suspense>
      </div>
      <p className="mt-4 text-center text-sm text-muted">
        New here?{" "}
        <Link href="/register" className="font-medium text-primary-strong hover:underline">
          Create an account
        </Link>
      </p>
    </div>
  );
}
