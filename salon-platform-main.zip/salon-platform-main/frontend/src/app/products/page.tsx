/**
 * Public shop page (US-07): server-rendered product grid; each tile is a
 * client component handling add-to-cart and stock badges.
 */
import type { Metadata } from "next";
import { serverGet } from "@/lib/server-api";
import type { Product } from "@/lib/types";
import { ProductCard } from "@/components/product-card";

export const metadata: Metadata = {
  title: "Shop Hair Products",
  description:
    "Salon-quality hair care — leave-in conditioners, oils, bonnets, and more. Order online and pay with Mobile Money.",
};

export default async function ProductsPage() {
  const products = await serverGet<Product[]>("/products");

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <h1 className="font-display text-3xl font-semibold">Shop products</h1>
      <p className="mt-2 max-w-xl text-muted">
        The same products we use in the salon, delivered to your door or picked up at your next
        appointment.
      </p>

      {!products ? (
        <p className="mt-8 rounded-2xl border border-dashed border-line p-10 text-center text-muted">
          We couldn&apos;t load the shop right now. Please refresh in a moment.
        </p>
      ) : products.length === 0 ? (
        <p className="mt-8 rounded-2xl border border-dashed border-line p-10 text-center text-muted">
          New products are on the way — check back soon!
        </p>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
