"use client";

/**
 * Site-wide sticky header: brand, main nav, theme toggle, cart badge, and
 * auth controls. Responsive per NFR-05 — full nav on desktop, hamburger
 * menu on mobile. The Dashboard link appears only for the admin role.
 */
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useCart } from "@/lib/cart-context";
import { ThemeToggle } from "./theme-toggle";
import { cx } from "./ui";

const NAV_LINKS = [
  { href: "/services", label: "Services" },
  { href: "/products", label: "Shop" },
];

export function Header() {
  const { user, logout } = useAuth();
  const { count } = useCart();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const linkClass = (href: string) =>
    cx(
      "rounded-full px-4 py-2 text-sm font-medium transition-colors",
      pathname.startsWith(href)
        ? "bg-primary-soft text-primary-strong"
        : "text-ink hover:bg-primary-soft/50",
    );

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-surface/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-2 px-4">
        <Link href="/" className="font-display text-xl font-semibold text-primary-strong">
          Beryl’s Beauty Mark
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          {NAV_LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={linkClass(l.href)}>
              {l.label}
            </Link>
          ))}
          {user?.role === "ADMIN" && (
            <Link href="/admin" className={linkClass("/admin")}>
              Dashboard
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-1">
          <ThemeToggle />
          <Link
            href="/cart"
            aria-label={`Cart, ${count} items`}
            className="relative flex h-9 w-9 items-center justify-center rounded-full text-lg hover:bg-primary-soft/60"
          >
            🛒
            {count > 0 && (
              <span className="absolute -top-0.5 -right-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-white">
                {count}
              </span>
            )}
          </Link>

          {/* Desktop auth */}
          <div className="hidden items-center gap-1 md:flex">
            {user ? (
              <>
                <Link href="/account" className={linkClass("/account")}>
                  {user.name.split(" ")[0]}
                </Link>
                <button
                  onClick={logout}
                  className="rounded-full px-4 py-2 text-sm text-muted hover:bg-primary-soft/50 cursor-pointer"
                >
                  Log out
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className={linkClass("/login")}>
                  Log in
                </Link>
                <Link
                  href="/register"
                  className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-strong"
                >
                  Sign up
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            className="flex h-9 w-9 items-center justify-center rounded-full text-xl md:hidden cursor-pointer hover:bg-primary-soft/60"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            {open ? "✕" : "☰"}
          </button>
        </div>
      </div>

      {/* Mobile nav */}
      {open && (
        <nav
          className="flex flex-col gap-1 border-t border-line bg-surface px-4 py-3 md:hidden"
          aria-label="Mobile"
        >
          {NAV_LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={linkClass(l.href)} onClick={() => setOpen(false)}>
              {l.label}
            </Link>
          ))}
          {user?.role === "ADMIN" && (
            <Link href="/admin" className={linkClass("/admin")} onClick={() => setOpen(false)}>
              Dashboard
            </Link>
          )}
          {user ? (
            <>
              <Link href="/account" className={linkClass("/account")} onClick={() => setOpen(false)}>
                My account
              </Link>
              <button
                onClick={() => {
                  logout();
                  setOpen(false);
                }}
                className="rounded-full px-4 py-2 text-left text-sm text-muted hover:bg-primary-soft/50"
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className={linkClass("/login")} onClick={() => setOpen(false)}>
                Log in
              </Link>
              <Link href="/register" className={linkClass("/register")} onClick={() => setOpen(false)}>
                Sign up
              </Link>
            </>
          )}
        </nav>
      )}
    </header>
  );
}
