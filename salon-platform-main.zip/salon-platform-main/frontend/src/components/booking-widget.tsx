"use client";

/**
 * The booking flow (US-04/US-05), a three-step wizard:
 *   pick  — choose a date, see live availability + per-slot status
 *   pay   — booking created (PENDING_PAYMENT), confirm via Mobile Money
 *   done  — success screen; booking is CONFIRMED once payment succeeds
 * Cap/slot conflicts from racing customers surface as 409s and trigger an
 * availability refresh so the user immediately sees what's still open.
 */
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, ApiClientError } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import type { Availability, Booking, Service } from "@/lib/types";
import { formatGHS } from "@/lib/money";
import { Button, ErrorNote, Input, Spinner, cx } from "./ui";

/** Earliest bookable date given the advance-notice rule (US-04 AC2). */
function defaultDate(minAdvanceDays: number): string {
  const d = new Date();
  d.setDate(d.getDate() + minAdvanceDays);
  return d.toISOString().slice(0, 10);
}

type Step = "pick" | "pay" | "done";

export function BookingWidget({ service }: { service: Service }) {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [step, setStep] = useState<Step>("pick");
  const [date, setDate] = useState(() => defaultDate(2));
  const [slot, setSlot] = useState<string | null>(null);
  const [availability, setAvailability] = useState<Availability | null>(null);
  const [checking, setChecking] = useState(false);
  const [booking, setBooking] = useState<Booking | null>(null);
  const [momoNumber, setMomoNumber] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);

  const checkAvailability = useCallback(
    async (d: string) => {
      setChecking(true);
      setError(null);
      setSlot(null);
      try {
        const result = await api<Availability>(
          `/bookings/availability?serviceId=${service.id}&date=${d}`,
          { auth: false },
        );
        setAvailability(result);
      } catch (e) {
        setError(e instanceof ApiClientError ? e.message : "Could not check availability");
        setAvailability(null);
      } finally {
        setChecking(false);
      }
    },
    [service.id],
  );

  useEffect(() => {
    // Small debounce: avoids refetch spam while the user changes the date
    const handle = window.setTimeout(() => void checkAvailability(date), 200);
    return () => window.clearTimeout(handle);
  }, [date, checkAvailability]);

  async function book() {
    if (!user) {
      router.push(`/login?next=/services/${service.id}`);
      return;
    }
    if (!slot) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ booking: Booking; payment: { amountMinor: number } }>("/bookings", {
        method: "POST",
        body: { serviceId: service.id, date, timeSlot: slot },
      });
      setBooking(res.booking);
      setMomoNumber(user.phone);
      setStep("pay");
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Booking failed");
      if (e instanceof ApiClientError && (e.code === "DAILY_CAP_REACHED" || e.code === "SLOT_TAKEN")) {
        void checkAvailability(date);
      }
    } finally {
      setBusy(false);
    }
  }

  async function pay() {
    if (!booking) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ reference: string; status: string }>("/payments/initiate", {
        method: "POST",
        body: { type: "booking", refId: booking.id, momoNumber },
      });
      setPaymentStatus(res.status);
      if (res.status === "FAILED") {
        setError("Payment was declined. Please check the number and try again.");
      } else {
        setStep("done");
      }
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Payment failed");
    } finally {
      setBusy(false);
    }
  }

  if (step === "done") {
    return (
      <div className="rounded-2xl border border-success/30 bg-success/10 p-6 text-center">
        <p className="text-4xl" aria-hidden>
          🎉
        </p>
        <h3 className="mt-2 font-display text-xl font-semibold">
          {paymentStatus === "SUCCESS" ? "Booking confirmed!" : "Almost there!"}
        </h3>
        <p className="mt-2 text-sm text-muted">
          {paymentStatus === "SUCCESS"
            ? `See you on ${date} at ${slot}. A confirmation is saved in your account.`
            : "Approve the payment prompt on your phone to confirm the booking."}
        </p>
        <Button className="mt-4" onClick={() => router.push("/account")}>
          View my bookings
        </Button>
      </div>
    );
  }

  if (step === "pay" && booking) {
    return (
      <div className="rounded-2xl border border-line bg-surface p-6">
        <h3 className="font-display text-lg font-semibold">Confirm with Mobile Money</h3>
        <p className="mt-1 text-sm text-muted">
          {service.name} · {date} at {slot}
        </p>
        <p className="mt-3 text-2xl font-semibold text-primary-strong">
          {formatGHS(service.priceMin)}
        </p>
        <p className="text-xs text-muted">
          Base price paid now to reserve your slot; extras are settled at the salon.
        </p>
        <div className="mt-4">
          <Input
            id="momo"
            label="Mobile Money number"
            inputMode="tel"
            value={momoNumber}
            onChange={(e) => setMomoNumber(e.target.value)}
            placeholder="e.g. 0241234567"
          />
        </div>
        {error && (
          <div className="mt-3">
            <ErrorNote message={error} />
          </div>
        )}
        <Button className="mt-4 w-full" onClick={pay} loading={busy}>
          Pay {formatGHS(service.priceMin)}
        </Button>
        <p className="mt-2 text-center text-xs text-muted">
          Your unpaid slot is held for 30 minutes.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-line bg-surface p-6">
      <h3 className="font-display text-lg font-semibold">Book this service</h3>

      <div className="mt-4">
        <Input
          id="booking-date"
          label="Pick a date"
          type="date"
          value={date}
          min={defaultDate(availability?.minAdvanceDays ?? 2)}
          onChange={(e) => setDate(e.target.value)}
        />
        <p className="mt-1 text-xs text-muted">
          Bookings open {availability?.minAdvanceDays ?? 2} days ahead so we can prepare for you.
        </p>
      </div>

      <div className="mt-4 min-h-24">
        {checking ? (
          <div className="flex justify-center py-6 text-primary">
            <Spinner />
          </div>
        ) : availability ? (
          availability.available ? (
            <>
              <p className="text-sm font-medium">
                Choose a time{" "}
                <span className="font-normal text-muted">
                  ({availability.slotsRemaining} of {availability.dailyCap} day-slots left)
                </span>
              </p>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {availability.timeSlots.map(({ slot: s, available }) => (
                  <button
                    key={s}
                    disabled={!available}
                    onClick={() => setSlot(s)}
                    className={cx(
                      "rounded-xl border px-2 py-2 text-sm transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-35",
                      slot === s
                        ? "border-primary bg-primary text-white"
                        : "border-line bg-surface hover:border-primary",
                    )}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </>
          ) : (
            <p className="rounded-xl bg-warning/10 px-4 py-3 text-sm text-warning">
              This date is fully booked for {service.category.name.toLowerCase()} styles. Please
              try another day.
            </p>
          )
        ) : null}
      </div>

      {error && (
        <div className="mt-3">
          <ErrorNote message={error} />
        </div>
      )}

      <Button
        className="mt-4 w-full"
        onClick={book}
        disabled={!slot || checking}
        loading={busy || authLoading}
      >
        {user ? "Reserve & pay" : "Log in to book"}
      </Button>
    </div>
  );
}
