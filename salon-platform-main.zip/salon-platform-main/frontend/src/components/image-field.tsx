"use client";

/**
 * Image picker for admin forms: choose a file, it uploads immediately
 * and fills the form's imageUrl with the hosted URL, with a live
 * thumbnail preview. Replaces the old paste-a-URL input.
 */
import { useRef, useState } from "react";
import { apiUploadImage, ApiClientError } from "@/lib/api";
import { Button } from "@/components/ui";

export function ImageField({
  label = "Photo",
  value,
  onChange,
}: {
  label?: string;
  value: string;
  onChange: (url: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function pick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-picking the same file
    if (!file) return;
    setError(null);
    setBusy(true);
    try {
      onChange(await apiUploadImage(file));
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-sm font-medium text-ink">{label}</span>
      <div className="flex items-center gap-3">
        {value ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={value}
            alt="Preview"
            className="h-16 w-16 rounded-xl border border-line object-cover"
          />
        ) : (
          <div className="flex h-16 w-16 items-center justify-center rounded-xl border border-dashed border-line text-2xl">
            <span aria-hidden>🖼️</span>
          </div>
        )}
        <div className="flex flex-wrap gap-2">
          <Button
            type="button"
            variant="secondary"
            className="px-4 py-2 text-xs"
            loading={busy}
            onClick={() => inputRef.current?.click()}
          >
            {value ? "Replace image" : "Upload image"}
          </Button>
          {value && (
            <Button
              type="button"
              variant="ghost"
              className="px-4 py-2 text-xs"
              onClick={() => onChange("")}
            >
              Remove
            </Button>
          )}
        </div>
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          className="hidden"
          onChange={pick}
        />
      </div>
      <p className="text-xs text-muted">JPEG, PNG, WebP, or GIF — up to 5MB.</p>
      {error && <p className="text-xs text-danger">{error}</p>}
    </div>
  );
}
