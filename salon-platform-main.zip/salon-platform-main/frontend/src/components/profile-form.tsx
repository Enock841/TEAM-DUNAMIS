"use client";

/**
 * Edit-profile form (name / phone / email) shared by the customer and
 * admin settings pages. Phone and email double as login identifiers,
 * so the API enforces uniqueness and the form surfaces conflicts.
 */
import { useState } from "react";
import { ApiClientError } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import { Button, Card, ErrorNote, Input } from "@/components/ui";

export function ProfileForm() {
  const { user, updateProfile } = useAuth();
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  if (!user) return null;
  const dirty =
    name !== user.name || phone !== user.phone || email !== (user.email ?? "");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setDone(false);
    setBusy(true);
    try {
      await updateProfile({
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim() || null,
      });
      setDone(true);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not save profile");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card>
      <h2 className="font-display text-lg font-semibold">Profile</h2>
      <p className="mt-1 text-sm text-muted">
        You sign in with your phone number{email ? " or email" : ""}, so keep them current.
      </p>
      <form onSubmit={submit} className="mt-4 grid max-w-md gap-4">
        <Input
          id="profile-name"
          label="Full name"
          autoComplete="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          minLength={2}
        />
        <Input
          id="profile-phone"
          label="Phone number"
          type="tel"
          autoComplete="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
          pattern="\+?\d{9,15}"
          title="Digits only, e.g. 0241234567"
        />
        <Input
          id="profile-email"
          label="Email (optional)"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        {error && <ErrorNote message={error} />}
        {done && (
          <p
            role="status"
            className="rounded-xl border border-success/30 bg-success/10 px-4 py-3 text-sm text-success"
          >
            Profile saved.
          </p>
        )}
        <div>
          <Button type="submit" loading={busy} disabled={!dirty}>
            Save profile
          </Button>
        </div>
      </form>
    </Card>
  );
}
