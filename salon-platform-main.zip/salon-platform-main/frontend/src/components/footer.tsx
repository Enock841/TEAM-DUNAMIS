import Link from "next/link";

/** Site footer: brand blurb, visiting details (placeholders), quick links. */
export function Footer() {
  return (
    <footer className="mt-16 border-t border-line bg-surface">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-3">
        <div>
          <p className="font-display text-lg font-semibold text-primary-strong">Beryl’s Beauty Mark</p>
          <p className="mt-2 text-sm text-muted">
            Protective styles, healthy hair care, and the products to keep them beautiful.
          </p>
        </div>
        <div>
          <p className="text-sm font-semibold">Visit</p>
          <ul className="mt-2 space-y-1 text-sm text-muted">
            <li>Kumasi, Ghana</li>
            <li>Tue – Sat · 8:00 – 17:00</li>
            <li>
              <a href="tel:+233240000000" className="hover:text-primary-strong">
                +233 24 000 0000
              </a>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold">Quick links</p>
          <ul className="mt-2 space-y-1 text-sm text-muted">
            <li>
              <Link href="/services" className="hover:text-primary-strong">
                Book a service
              </Link>
            </li>
            <li>
              <Link href="/products" className="hover:text-primary-strong">
                Shop products
              </Link>
            </li>
            <li>
              <Link href="/account" className="hover:text-primary-strong">
                My bookings
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <p className="border-t border-line py-4 text-center text-xs text-muted">
        © {new Date().getFullYear()} Beryl’s Beauty Mark · Built by Team Dunamis
      </p>
    </footer>
  );
}
