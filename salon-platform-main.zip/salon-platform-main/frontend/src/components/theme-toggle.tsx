"use client";

/**
 * Light/dark mode toggle. With no saved preference the site follows the
 * system theme (via the prefers-color-scheme rules in globals.css); a
 * click stores an explicit override in localStorage and applies it by
 * setting data-theme on <html>.
 */
import { useEffect, useState } from "react";

// null = no explicit preference: follow the system setting
type Theme = "light" | "dark" | null;

function systemPrefersDark(): boolean {
  return window.matchMedia("(prefers-color-scheme: dark)").matches;
}

export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // Deferred so the stored preference lands after hydration
    queueMicrotask(() => {
      const stored = window.localStorage.getItem("salon_theme") as Theme;
      if (stored) {
        setTheme(stored);
        document.documentElement.dataset.theme = stored;
      }
      setMounted(true);
    });
  }, []);

  if (!mounted) return <div className="h-9 w-9" aria-hidden />;

  const effectiveDark = theme ? theme === "dark" : systemPrefersDark();

  const toggle = () => {
    const next: Theme = effectiveDark ? "light" : "dark";
    setTheme(next);
    document.documentElement.dataset.theme = next;
    window.localStorage.setItem("salon_theme", next);
  };

  return (
    <button
      onClick={toggle}
      aria-label={effectiveDark ? "Switch to light mode" : "Switch to dark mode"}
      className="flex h-9 w-9 items-center justify-center rounded-full text-lg hover:bg-primary-soft/60 cursor-pointer"
    >
      {effectiveDark ? "☀️" : "🌙"}
    </button>
  );
}
