"use client";

/**
 * Change-password form shared by the customer settings page and the
 * admin settings page. Verifies the current password server-side.
 */
import { useState } from "react";
import { api, ApiClientError } from "@/lib/api";
import { Button, Card, ErrorNote, PasswordInput } from "@/components/ui";

export function ChangePasswordForm() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setDone(false);
    if (next !== confirm) {
      setError("New passwords do not match");
      return;
    }
    setBusy(true);
    try {
      await api("/auth/password", {
        method: "PUT",
        body: { currentPassword: current, newPassword: next },
      });
      setCurrent("");
      setNext("");
      setConfirm("");
      setDone(true);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not change password");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card>
      <h2 className="font-display text-lg font-semibold">Change password</h2>
      <p className="mt-1 text-sm text-muted">
        Use at least 8 characters. You&apos;ll stay signed in on this device.
      </p>
      <form onSubmit={submit} className="mt-4 grid max-w-md gap-4">
        <PasswordInput
          id="pw-current"
          label="Current password"
          autoComplete="current-password"
          value={current}
          onChange={(e) => setCurrent(e.target.value)}
          required
        />
        <PasswordInput
          id="pw-new"
          label="New password"
          autoComplete="new-password"
          value={next}
          onChange={(e) => setNext(e.target.value)}
          required
          minLength={8}
        />
        <PasswordInput
          id="pw-confirm"
          label="Confirm new password"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          required
          minLength={8}
        />
        {error && <ErrorNote message={error} />}
        {done && (
          <p
            role="status"
            className="rounded-xl border border-success/30 bg-success/10 px-4 py-3 text-sm text-success"
          >
            Password updated.
          </p>
        )}
        <div>
          <Button type="submit" loading={busy}>
            Update password
          </Button>
        </div>
      </form>
    </Card>
  );
}
