"use client";

/**
 * Storefront product tile (US-07): image, price, stock badges ("Out of
 * stock" / "Only N left"), and add-to-cart with a brief confirmation
 * state. Out-of-stock products render but cannot be added (US-07 AC3).
 */
import { useState } from "react";
import type { Product } from "@/lib/types";
import { useCart } from "@/lib/cart-context";
import { formatGHS } from "@/lib/money";
import { Badge, Button } from "./ui";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);

  function handleAdd() {
    add(product);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1200);
  }

  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-line bg-surface">
      <div className="relative flex h-40 items-center justify-center bg-surface-2 text-5xl">
        {product.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={product.imageUrl} alt={product.name} className="h-full w-full object-cover" />
        ) : (
          <span aria-hidden>🧴</span>
        )}
        {!product.inStock && (
          <span className="absolute top-3 right-3">
            <Badge tone="danger">Out of stock</Badge>
          </span>
        )}
        {product.inStock && product.stockQty <= 5 && (
          <span className="absolute top-3 right-3">
            <Badge tone="warning">Only {product.stockQty} left</Badge>
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-medium">{product.name}</h3>
        <p className="mt-1 line-clamp-2 flex-1 text-sm text-muted">{product.description}</p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <p className="font-semibold text-primary-strong">{formatGHS(product.price)}</p>
          <Button
            variant={added ? "secondary" : "primary"}
            className="px-4 py-2"
            disabled={!product.inStock}
            onClick={handleAdd}
          >
            {added ? "Added ✓" : product.inStock ? "Add to cart" : "Unavailable"}
          </Button>
        </div>
      </div>
    </div>
  );
}
